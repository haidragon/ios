
#ifndef hookzz_internal_h
#define hookzz_internal_h

#include "core.h"
#include "hookzz.h"

bool zz_is_near_jump();

#endif