#include "closure_bridge.h"

DynamicClosureBridge *DynamicClosureBridgeCClass(SharedInstance)() { return NULL; }
DynamicClosureBridgeInfo *DynamicClosureBridgeCClass(AllocateDynamicClosureBridge)(DynamicClosureBridge *self,
                                                                                   void *user_data, void *user_code) {
    return NULL;
}
DynamicClosureBridgeTrampolineTable *
DynamicClosureBridgeCClass(AllocateDynamicClosureBridgeTrampolineTable)(DynamicClosureBridge *self) {
    return NULL;
}
