#include "regs-x86.h"

void x86_register_describe(X86Reg reg, X86RegInfo *ri) {}
