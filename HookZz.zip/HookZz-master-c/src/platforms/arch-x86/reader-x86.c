#include "reader-x86.h"
X86Reader *x86_reader_new(zz_ptr_t insn_address) { return NULL; }

void x86_reader_init(X86Reader *self, zz_ptr_t insn_address) {}

void x86_reader_reset(X86Reader *self, zz_ptr_t insn_address) {}

void x86_reader_free(X86Reader *self) {}

X86Instruction *x86_reader_read_one_instruction(X86Reader *self) {}

X86InsnType GetX86InsnType(uint32_t insn) {}