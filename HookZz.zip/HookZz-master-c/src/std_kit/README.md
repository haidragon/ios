**0x1 std_list**

[std_list](https://github.com/clibs/list/blob/master/src/list.h)