#include "ARM64Helper.h"

#include "hookzz.h"

void *get_next_hop_addr_PTR(RegState *rs) {}

void *get_ret_addr_PTR(RegState *rs) {}