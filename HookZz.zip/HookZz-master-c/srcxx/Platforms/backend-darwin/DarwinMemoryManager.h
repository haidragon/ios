//
// Created by jmpews on 2018/6/14.
//

#ifndef HOOKZZ_DARWINMEMORYMANAGER_H
#define HOOKZZ_DARWINMEMORYMANAGER_H

#include "MemoryManager.h"

#endif //HOOKZZ_DARWINMEMORYMANAGER_H
