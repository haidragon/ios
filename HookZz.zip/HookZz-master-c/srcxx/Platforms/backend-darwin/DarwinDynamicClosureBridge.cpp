//
// Created by jmpews on 2018/6/15.
//

#include "DarwinDynamicClosureBridge.h"
#include "ClosureBridge.h"


DynamicClosureBridgeInfo *DynamicClosureBridge::allocateDynamicClosureBridge(void *user_data, void *user_code) {return NULL;}

DynamicClosureBridgeTrampolineTable* DynamicClosureBridge::addDynamicClosurceBridgeTrampolineTable() {return NULL;}