//
// Created by jmpews on 2018/6/14.
//

#ifndef HOOKZZ_POSIXCLOSUREBRIDGE_H
#define HOOKZZ_POSIXCLOSUREBRIDGE_H

#include "ClosureBridge.h"
#include "PosixClosureBridge.h"

#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#endif //HOOKZZ_POSIXCLOSUREBRIDGE_H
