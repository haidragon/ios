//
// Created by jmpews on 2018/6/14.
//

#include "Singleton.h"

// template <typename T> T *Singleton<T>::_instance = NULL;

// template <typename T> T *Singleton<T>::GetInstance() {
//     if (_instance == NULL) {
//         _instance = new T();
//     }
//     return _instance;
// }