//
// Created by z on 2018/6/14.
//

#ifndef HOOKZZ_TRAMPOLINE_H
#define HOOKZZ_TRAMPOLINE_H

class Trampoline {};

#endif //HOOKZZ_TRAMPOLINE_H
