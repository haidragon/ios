//
//  main.swift
//  JSONKitTest
//
//  Created by wuxing on 14/7/18.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

func testJson() {
    //Swift 字典对象
    let user = [
        "uname": "user1",
        "tel": ["mobile": "138", "home": "010"]
    ]
    //使用 JSONKit 转换成为 JSON 字符串
    var jsonstring = (user as NSDictionary).JSONString()
    println(jsonstring);
    //由字符串反解析回字典
    println(jsonstring.objectFromJSONString() as! NSDictionary)
    
    //使用 JSONKit 转换成为 NSData 类型的 JSON 数据
    var jsondata = (user as NSDictionary).JSONData()
    println(jsondata);
    //由NSData 反解析回为字典
    println(jsondata.objectFromJSONData() as! NSDictionary)
    
}
testJson()
