// Playground - noun: a place where people can play

import Cocoa

let decimalString = "decimal: " + String(31)
var str = String(format: "%0x", 89)
let hexString = "hex: \(str)"

println(decimalString)
println(hexString)

var arr = Array<Int>()
arr += [10]

println(arr)

