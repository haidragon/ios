//
//  KKColorsSchemeType.h
//  KKColorListPickerExample
//
//  Created by Kirill Kunst on 28.12.13.
//  Copyright (c) 2013 Kirill Kunst. All rights reserved.
//

typedef NS_ENUM(NSInteger, KKColorsSchemeType)
{
    KKColorsSchemeTypeCrayola,
    KKColorsSchemeTypePantone,
};
