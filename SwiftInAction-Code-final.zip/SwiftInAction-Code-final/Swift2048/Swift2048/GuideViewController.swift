//
//  GuideViewController.swift
//  Swift2048-012
//
//  Created by wuxing on 14/7/3.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit

class GuideViewController:UIViewController,UIScrollViewDelegate
{
    var numOfPages = 3
    
    override func viewDidLoad()
    {
        var frame = self.view.bounds
        //scrollView的初始化
        var scrollView=UIScrollView()
        scrollView.frame=self.view.bounds
        scrollView.delegate = self
        //为了能让内容横向滚动，设置横向内容宽度为3个页面的宽度总和
        scrollView.contentSize=CGSizeMake(frame.size.width*CGFloat(numOfPages),frame.size.height)
        println("\(frame.size.width*CGFloat(numOfPages)),\(frame.size.height)")
        scrollView.pagingEnabled=true
        scrollView.showsHorizontalScrollIndicator=false
        scrollView.showsVerticalScrollIndicator=false
        scrollView.scrollsToTop=false
        for i in 0..<numOfPages{
            var imgfile = "jianjie\(Int(i+1)).png"
            println(imgfile)
            var image = UIImage(named:"\(imgfile)")
            var imgView = UIImageView(image: image)
            imgView.frame=CGRectMake(frame.size.width*CGFloat(i),CGFloat(0),frame.size.width,frame.size.height)
            scrollView.addSubview(imgView)
        }
        scrollView.contentOffset = CGPointZero
        self.view.addSubview(scrollView)
    }
    func scrollViewDidScroll(scrollView: UIScrollView!)
    {
        println("scrolled:\(scrollView.contentOffset)")
        var twidth = CGFloat(numOfPages-1) * self.view.bounds.size.width
        if(scrollView.contentOffset.x > twidth)
        {
            var mainStoryboard = UIStoryboard(name:"Main", bundle:nil)
            var viewController = mainStoryboard.instantiateInitialViewController()  as! UIViewController
            
            self.presentViewController(viewController, animated: true, completion:nil)
            
        }
    }
}
