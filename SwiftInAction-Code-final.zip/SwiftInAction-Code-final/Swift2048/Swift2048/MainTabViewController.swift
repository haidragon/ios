//
//  MainTabViewController.swift
//  Swift2048-002
//
//  Created by wuxing on 14-6-9.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit

class MainTabViewController:UITabBarController,KKColorListViewControllerDelegate
{
    var viewMain:MainViewController!
    var viewColor:KKColorListViewController!
    
    required init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!)
    {
        
        viewMain = MainViewController()
        viewColor = KKColorListViewController(schemeType:KKColorsSchemeType.Crayola)
        super.init(nibName:nibNameOrNil, bundle:nibBundleOrNil)
        viewMain.title = "2048"
        
        var viewSetting = SettingViewController(mainview:viewMain)
        
        viewSetting.title = "设置"
    
        viewColor.title = "背景"
        viewColor.headerTitle = "选择背景色"
        viewColor.delegate =  self
        
        var main = UINavigationController(rootViewController:viewMain)
        var setting = UINavigationController(rootViewController:viewSetting)
        var color = UINavigationController(rootViewController:viewColor)
        
        self.viewControllers = [
            main, setting, color
        ]
        
        self.selectedIndex = 0
    }
    //处理颜色选中
    func colorListController(controller:KKColorListViewController,  didSelectColor color:KKColor)
    {
        viewMain.view.backgroundColor = color.uiColor()
        //保存颜色数据到SQLite数据中
        var usermodel = UserModel()
        usermodel.save_color(color.uiColor())
        self.selectedIndex = 0
    }
    //处理取消选中
    func colorListPickerDidComplete(controller:KKColorListViewController)
    {
        self.selectedIndex = 0
    }
    
}
