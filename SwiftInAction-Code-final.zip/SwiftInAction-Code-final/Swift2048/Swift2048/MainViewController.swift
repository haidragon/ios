//
//  MainViewController.swift
//  Swift2048-002
//
//  Created by wuxing on 14-6-9.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit

enum Animation2048Type
{
    case None   //无动画
    case New    //新出现动画
    case Merge  //合并动画
}
extension String {
    var floatValue: Float {
    return (self as NSString).floatValue
    }
    
}
class MainViewController:UIViewController
{
    //游戏方格维度
    var dimension:Int = 4{
        didSet{
            gmodel.dimension = dimension
        }
    }
    required init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
    }
    func saveScore()
    {
        
        scorectrl.saveScore(gmodel.bestscore, userid: UserModel.get_uuid())
    }
     

    //游戏过关最大值
    var maxnumber:Int = 16 {
        didSet{
            gmodel.maxnumber = maxnumber
        }
    }
    
    //数字格子的宽度
    var width:CGFloat = 50
    //格子与格子的间距
    var padding:CGFloat = 6
    
    //保存背景图数据
    var backgrounds:Array<UIView>!
    
    //游戏数据模型
    var gmodel:GameModel!
    
    //保存界面上的数字Label数据
    var tiles: Dictionary<NSIndexPath, TileView>!
    //保存实际数字值的一个字典
    var tileVals: Dictionary<NSIndexPath, Int>!
    
    var score:ScoreView!
    
    var bestscore:ScoreView!
    
    var scorectrl:ScoreController!
    
    init()
    {
        self.backgrounds = Array<UIView>()
        
        let user = UserModel(dimension: dimension, maxnum: maxnumber, backgroundColor: UIColor.whiteColor())
        var data:Dictionary<String, String> = user.get_userdata()
        self.dimension = data["dimension"]!.toInt()!
        self.maxnumber = data["maxnum"]!.toInt()!
        println(data)
        var count = self.dimension*self.dimension
       // self.tiles = Array<TileView>(count:count, repeatedValue:0)
        self.tiles = Dictionary()
        self.tileVals = Dictionary()
        
       
        super.init(nibName:nil, bundle:nil)
    }
  
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let user = UserModel()
        var data:Dictionary<String, String> = user.get_userdata()
       
        var red = CGFloat(data["red"]!.floatValue)
        var green = CGFloat(data["green"]!.floatValue)
        var blue = CGFloat(data["blue"]!.floatValue)
        var alpha = CGFloat(data["alpha"]!.floatValue)
        
        self.view.backgroundColor = UIColor(red:red,green:green, blue:blue, alpha:alpha)
        setupBackground()
        setupButtons()
        setupSwipeGuestures()
        setupScoreLabels()
        self.gmodel = GameModel(dimension: self.dimension,
            maxnumber:maxnumber, score:score, bestscore:bestscore)
        scorectrl = ScoreController(game:self.gmodel)
        scorectrl.getScore(UserModel.get_uuid())
        for i in 0..<2
        {
            genNumber()
        }
    }
    func getScore()
    {
        
    }
    
    func setupButtons()
    { 
        var btnreset = ViewFactory.createButton("重置", action: Selector("resetTapped"), sender:self)
        btnreset.frame.origin.x = 50
        btnreset.frame.origin.y = 450
        self.view.addSubview(btnreset)
        
        var btngen = ViewFactory.createButton("新数",
            action:Selector("genTapped"),sender:self)
        btngen.frame.origin.x = 170
        btngen.frame.origin.y = 450
        self.view.addSubview(btngen)
        
    }
    
    func setupScoreLabels()
    {
        score = ScoreView(stype: ScoreType.Common)
        score.frame.origin = CGPointMake(50, 80)
        score.changeScore(value: 0)
        self.view.addSubview(score)
        
        
        bestscore = ScoreView(stype: ScoreType.Best)
        bestscore.frame.origin.x = 170
        bestscore.frame.origin.y = 80
        bestscore.changeScore(value: 0)
        self.view.addSubview(bestscore)
        
    }
    
    func setupBackground()
    {
        var x:CGFloat = 0
        var y:CGFloat = 150
        
        var startx:Dictionary<Int, Int> = [3:70, 4:50, 5:30]
        x = CGFloat(startx[dimension]!)
        
        for i in 0..<dimension
        {
            println(i)
            y = 150
            for j in 0..<dimension
            {
                var background = UIView(frame:CGRectMake(x, y, width, width))
                background.backgroundColor = UIColor.darkGrayColor()
                
                self.view.addSubview(background)
                backgrounds.append(background)
                y += padding + width
            }
            x += padding+width
        }
    }
    
    func setupSwipeGuestures()
    {
        let upSwipe = UISwipeGestureRecognizer(target:self, action:Selector("swipeUp"))
        
        upSwipe.numberOfTouchesRequired = 1
        upSwipe.direction = UISwipeGestureRecognizerDirection.Up
        self.view.addGestureRecognizer(upSwipe)
        
        let downSwipe = UISwipeGestureRecognizer(target: self, action: Selector("swipeDown"))
        downSwipe.numberOfTouchesRequired = 1
        downSwipe.direction = UISwipeGestureRecognizerDirection.Down
        self.view.addGestureRecognizer(downSwipe)
        
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: Selector("swipeLeft"))
        leftSwipe.numberOfTouchesRequired = 1
        leftSwipe.direction = UISwipeGestureRecognizerDirection.Left
        self.view.addGestureRecognizer(leftSwipe)
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: Selector("swipeRight"))
        rightSwipe.numberOfTouchesRequired = 1
        rightSwipe.direction = UISwipeGestureRecognizerDirection.Right
        self.view.addGestureRecognizer(rightSwipe)
        
    }
    func printTiles(tiles:Array<Int>)
    {
        var count = tiles.count
        for var i=0; i<count; i++
        {
            if (i+1) % Int(dimension) == 0
            {
                println(tiles[i])
            }
            else
            {
                print("\(tiles[i])\t")
            }
        }
        
        println("")
        
    }
    func swipeUp()
    {
        println("swipeUp")
        
        gmodel.reflowUp()
        gmodel.mergeUp()
        gmodel.reflowUp()
        
        printTiles(gmodel.tiles)
        printTiles(gmodel.mtiles)
        
      //  resetUI()
        initUI()
        if(!gmodel.isSuccess())
        {
            genNumber()
        }
        /*for i in 0..dimension
        {
            for j in 0..dimension
            {
                var row:Int = i
                var col:Int = j
                var key = NSIndexPath(forRow:row, inSection:col)
                if(tileVals.indexForKey(key) != nil)
                {
                    //如果行> 3 上移一行
                    if(row>1)
                    {
                        var value = tileVals[key]
                        removeKeyTile(key)
                        
                        var index = row*dimension+col - dimension
                        row = Int(index/dimension)
                        col = index - row*dimension
                        insertTile((row,col), value:value!)
                    }
                }
            }
        }*/
    }
    
    func swipeDown()
    {
        println("swipeDown")
        gmodel.reflowDown()
        gmodel.mergeDown()
        gmodel.reflowDown()
        
        printTiles(gmodel.tiles)
        printTiles(gmodel.mtiles)
        
      //  resetUI()
        initUI()
        if(!gmodel.isSuccess())
        {
           genNumber()
        }
    }
    
    func swipeLeft()
    {
        println("swipeLeft")
        gmodel.reflowLeft()
        gmodel.mergeLeft()
        gmodel.reflowLeft()
        
        printTiles(gmodel.tiles)
        printTiles(gmodel.mtiles)
        
      //  resetUI()
        initUI()
        if(!gmodel.isSuccess())
        {
        genNumber()
        }
    }
    
    func swipeRight()
    {
        println("swipeRight")
        gmodel.reflowRight()
        gmodel.mergeRight()
        gmodel.reflowRight()
        printTiles(gmodel.tiles)
        printTiles(gmodel.mtiles)
        
     //   resetUI()
        initUI()
        if(!gmodel.isSuccess())
        {
            genNumber()
        }
    }
    
    
    func removeKeyTile(key:NSIndexPath)
    {
        var tile = tiles[key]!
        var tileVal = tileVals[key]
        
        tile.removeFromSuperview()
        tiles.removeValueForKey(key)
        tileVals.removeValueForKey(key)
    }
    
    func resetTapped()
    {
        println("reset")
        resetUI()
        gmodel.initTiles()
        for i in 0..<2
        {
            genNumber()
        }
    }
    func initUI()
    {
        
        var index:Int
        var key:NSIndexPath
        var tile:TileView
        var tileVal:Int
    
        
        for i in 0..<dimension
        {
            for j in 0..<dimension
            {
                index = i*self.dimension + j
                key = NSIndexPath(forRow:i, inSection:j)
                //原来界面没有值，模型数据中有值
                if((gmodel.tiles[index]>0) && tileVals.indexForKey(key)==nil)
                {
                    insertTile((i,j),value:gmodel.tiles[index], atype:Animation2048Type.Merge)
                }
                //原来界面中有值，现在模型中没有值 了
                if((gmodel.tiles[index] == 0) && (tileVals.indexForKey(key) != nil))
                {
                    tile = tiles[key]!
                    tile.removeFromSuperview()
                    
                    tiles.removeValueForKey(key)
                    tileVals.removeValueForKey(key)
                }
                //原来值，但是现在还有值
                if((gmodel.tiles[index] > 0) && (tileVals.indexForKey(key) != nil))
                {
                    tileVal = tileVals[key]!
                    if(tileVal != gmodel.tiles[index])
                    {
                        tile = tiles[key]!
                        tile.removeFromSuperview()
                        
                        tiles.removeValueForKey(key)
                        tileVals.removeValueForKey(key)
                        insertTile((i,j),value:gmodel.tiles[index],atype:Animation2048Type.Merge)
                    }
                }
                
                /*if(gmodel.tiles[index] != 0)
                {
                    insertTile((i,j),value:gmodel.tiles[index])
                }*/
            }
        }
        if(gmodel.isSuccess())
        {
            
            scorectrl.saveScore(gmodel.bestscore, userid:UserModel.get_uuid())
            var alertView = UIAlertView()
            alertView.title = "恭喜您通关"
            alertView.message = "嘿，真棒，您通关了！"
            alertView.addButtonWithTitle("确定")
            alertView.show()
            return;
        }
    }
    func resetUI()
    {
        for(key, tile) in tiles
        {
            tile.removeFromSuperview()
        }
        tiles.removeAll(keepCapacity: true)
        tileVals.removeAll(keepCapacity: true)
        
        for background in backgrounds {
            background.removeFromSuperview()
        }
        
        setupBackground()
        
        score.changeScore(value: 0)
        self.saveScore()
    }
    
    func genTapped()
    {
          println("genTapped")
        genNumber()
    }
    func genNumber()
    {
        let randv = Int(arc4random_uniform(10))
        println(randv)
        var seed:Int = 2
        if(randv == 1)
        {
            seed = 4
        }
        let col =  Int(arc4random_uniform(UInt32(dimension)))
        let row = Int(arc4random_uniform(UInt32(dimension)))
        
        if(gmodel.isFull())
        {
            println("位置已经满了")
            var alertView = UIAlertView()
            alertView.title = "Game Over"
            alertView.message = "Game Over！"
            alertView.addButtonWithTitle("确定")
            alertView.show()
            return
        }
        if(gmodel.setPosition(row, col:col, value:seed)==false)
        {
            genNumber()
            return
        }
        insertTile((row, col), value:seed, atype:Animation2048Type.New)
    }
    
    func insertTile(pos:(Int, Int), value:Int, atype:Animation2048Type)
    {
        let (row, col) = pos;
        
        var startx:Dictionary<Int, Int> = [3:70, 4:50, 5:30]
        
        
        let x = CGFloat(startx[dimension]!) + CGFloat(col) * (width + padding)
        let y = 150 + CGFloat(row) * (width + padding)
        
        let tile = TileView(pos: CGPointMake(x,y), width:width, value:value)
        self.view.addSubview(tile)
        self.view.bringSubviewToFront(tile)
        
        var index = NSIndexPath(forRow: row, inSection: col)
        tiles[index] = tile
        tileVals[index] = value
        if(atype == Animation2048Type.None)
        {
            return
        }
        else if(atype == Animation2048Type.New)
        {
            tile.layer.setAffineTransform(CGAffineTransformMakeScale(0.1,0.1))
        }
        else if(atype == Animation2048Type.Merge)
        {
            tile.layer.setAffineTransform(CGAffineTransformMakeScale(0.8,0.8))
        }
        UIView.animateWithDuration(0.3, delay:0.1, options:UIViewAnimationOptions.TransitionNone, animations:
            {
                ()-> Void in
                tile.layer.setAffineTransform(CGAffineTransformMakeScale(1,1))
            },
            completion:{
                (finished:Bool) -> Void in
                UIView.animateWithDuration(0.08, animations:{
                    ()-> Void in
                    tile.layer.setAffineTransform(CGAffineTransformIdentity)
                    })
                
            })
    }
}

