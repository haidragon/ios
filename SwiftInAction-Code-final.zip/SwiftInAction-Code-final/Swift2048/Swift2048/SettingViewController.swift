//
//  SettingViewController.swift
//  Swift2048-002
//
//  Created by wuxing on 14-6-9.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit

class SettingViewController:UIViewController, UITextFieldDelegate
{
    var mainview:MainViewController!
    
    var txtNum:UITextField!
    
    var segDimension:UISegmentedControl!
    
    required init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
    }
    
    override init(nibName nibNameOrNil: String!, bundle nibBundleOrNil: NSBundle!)
    {
        super.init(nibName:nibNameOrNil, bundle:nibBundleOrNil)
    }
    
    convenience init(mainview:MainViewController)
    {
        self.init(nibName:nil, bundle:nil)
        self.mainview = mainview

    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        
        setupControls()
        //存一次分数
        self.mainview.saveScore()
    }
    
    func setupControls()
    {
        //创建文本输入框
        txtNum = ViewFactory.createTextField(String(self.mainview.maxnumber)
            ,action:Selector("numChanged"), sender:self)
        
        txtNum.frame = CGRect(x:80,y:100,width:200,height:30)
        txtNum.returnKeyType = UIReturnKeyType.Done
        
        self.view.addSubview(txtNum)
        
        let labelNum = ViewFactory.createLabel("阈值:")
        labelNum.frame = CGRect(x: 20, y: 100, width: 60, height: 30)
        self.view.addSubview(labelNum)
        //创建分段单选控件
        segDimension = ViewFactory.createSegment(["3x3", "4x4", "5x5"], action:"dimensionChanged:", sender:self)
        
        segDimension.frame = CGRect(x:80,y: 200,width: 200,height: 30)
        
        self.view.addSubview(segDimension)
        let dman = [3:0,4:1,5:2]
        segDimension.selectedSegmentIndex = dman[mainview.dimension]!
        
        let labelDm = ViewFactory.createLabel("维度:")
        labelDm.frame = CGRect(x: 20, y: 200, width: 60, height: 30)
        self.view.addSubview(labelDm)
    }
    
    func textFieldShouldReturn(textField:UITextField) -> Bool
    {
        textField.resignFirstResponder()
        println("num Changed!")
        if(textField.text != "\(mainview.maxnumber)")
        {
            var num = textField.text.toInt()
            mainview.maxnumber = num!
        }
        //保存过关数字到本地SQLite数据库
        var usermodel = UserModel()
        usermodel.save_maxnum(mainview.maxnumber)
        return true
    }
    
    func dimensionChanged(sender:SettingViewController)
    {
        var segVals = [3,4,5]
        mainview.dimension  = segVals[segDimension.selectedSegmentIndex]
        mainview.resetTapped()
        //保存维度数据到本地SQLite数据库
        var usermodel = UserModel()
        usermodel.save_dimension(mainview.dimension)
        
    }
    
}
