//
//  ScoreView.swift
//  Swift2048-010
//
//  Created by wuxing on 14-6-9.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit
enum ScoreType{
    case Common  //普通分数面板
    case Best    //最高分面板
}
protocol ScoreViewProtocol{
   
    func changeScore(value s:Int)
}

class ScoreView:UIView, ScoreViewProtocol
{
    
    let defaultFrame = CGRectMake(0,0,100,30)
    var label:UILabel!

    var stype:String!  //显示”最高分“还是”分数“
    var score:Int = 0{
        willSet{
        //分数变化，标签内容也要变化
        label.text = "\(stype):\(newValue)"
        }
    }
    /*var score:Int = 0
    func setScore(score:Int)
    {
        self.score = score
        label.text = "\(self.stype):\(self.score)"
    }*/
    required init(coder aDecoder: NSCoder!) {
        super.init(coder: aDecoder)
    }
    
    //传入分数面板的类型，用于控制标签的显示
    
    init(stype:ScoreType)
    {
        super.init(frame: defaultFrame)
        
        label = UILabel(frame:defaultFrame)
        label.textAlignment = NSTextAlignment.Center
        
        
        self.stype = (stype == ScoreType.Common ? "分数:":"最高分")
        
        backgroundColor = UIColor.orangeColor()
        label.font = UIFont(name:"微软雅黑", size:16)
        label.textColor = UIColor.whiteColor()
        self.addSubview(label)
    }
    //实现协议中的方法
    func changeScore(value s:Int)
    {
        score = s
    }
}
 