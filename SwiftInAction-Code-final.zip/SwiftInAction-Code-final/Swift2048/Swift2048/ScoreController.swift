//
//  ScoreController.swift
//  Swift2048-012
//
//  Created by wuxing on 14/7/3.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit

class ScoreController:NSObject, NSURLConnectionDataDelegate
{
    var delegate:GameModel
    
    init(game:GameModel)
    {
        delegate = game
    }
    //保存分数
    func saveScore(score:Int, userid:String)
    {
        let urlString:String = "http://samples.app.ucai.cn/swiftinaction/savescore.php"
        var url:NSURL!
        url = NSURL(string:urlString)
        var request = NSMutableURLRequest(URL:url)
        var body = "score=\(score)&user=\(userid)"
        //编码POST数据
        var postData = body.dataUsingEncoding(NSASCIIStringEncoding)
        //保用 POST 提交
        request.HTTPMethod = "POST"
        request.HTTPBody = postData
        var   conn:NSURLConnection!
        conn = NSURLConnection(request: request,delegate: self)
        conn.start()
        println(conn)
    }
    //获取分数
    func getScore(user:String)
    {
        let urlString:String="http://samples.app.ucai.cn/swiftinaction/getscore.php?user=\(user)"
        var url:NSURL!
        url = NSURL(string:urlString)
        var request = NSMutableURLRequest(URL:url)
        
        var body = "user=\(user)"
        request.HTTPMethod = "GET"
        var conn:NSURLConnection!
        conn = NSURLConnection(request: request,delegate: self)
        conn.start()
        println(conn)
    }
    
     func connection(connection: NSURLConnection!, didReceiveResponse response: NSURLResponse!)
     {
        println("请求成功！");
        println(response)
    }
    
     func connection(connection: NSURLConnection!, didReceiveData data: NSData!)
     {
        println("请求成功1！");
        var datastring = NSString(data:data, encoding: NSUTF8StringEncoding)
        println(datastring)
        //解析 JSON 数据
        var json : AnyObject! = NSJSONSerialization.JSONObjectWithData(data,options:NSJSONReadingOptions.AllowFragments,error:nil)
        
        var act:AnyObject! = json?.objectForKey("act")
        //根据 act 来区分不同的请求
        if(act != nil && act as! NSString == "getscore")
        {
            delegate.bestscore = json.objectForKey("score") as! Int
        }
        println(act)
    }
    
     func connectionDidFinishLoading(connection: NSURLConnection!)
     {
         println("请求成功2！");
    }
}