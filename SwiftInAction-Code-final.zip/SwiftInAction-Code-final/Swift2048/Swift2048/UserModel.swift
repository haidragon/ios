//
//  UserModel.swift
//  Swift2048-012
//
//  Created by wuxing on 14/7/3.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class UserModel
{
    
    var db:SQLiteDB!
    class func get_uuid() -> String
    {
        var userid = NSUserDefaults.standardUserDefaults().stringForKey("swift2048user")
        if(userid != nil)
        {
            return userid!
        }
        else
        {
            var uuid_ref=CFUUIDCreate(nil)
            var uuid_string_ref=CFUUIDCreateString(nil, uuid_ref)
            //CFRelease(uuid_ref)
            var uuid:String = NSString(format: uuid_string_ref) as String
            NSUserDefaults.standardUserDefaults().setObject(uuid, forKey: "swift2048user")
            //CFRelease(uuid_string_ref)
            return uuid;
        }
    }
       //初始化数据
    init(dimension:Int, maxnum:Int, backgroundColor:UIColor)
    {
        db = SQLiteDB.sharedInstance()
        var cicolor:CIColor!
        cicolor = CIColor(color: backgroundColor)
        var red = cicolor.red()
        var green = cicolor.green()
        var blue = cicolor.blue()
        var alpha = cicolor.alpha()
        
        var userid = UserModel.get_uuid()
        let data = db.query("SELECT * FROM userdata WHERE userid='\(userid)'")
        //var d = data[0].data["dimension"]
        if(data.count == 0 || data[0].data["dimension"]!.integer == 0)
        {
            var sql = "INSERT INTO userdata(userid, dimension, maxnum, red,green,blue, alpha) VALUES('\(userid)',\(dimension),\(maxnum),\(red),\(green),\(blue),\(alpha) )"
             db.execute(sql)
        }
    }
    init()
    {
        db = SQLiteDB.sharedInstance()
    }
    //获得现在保存的数据
    func get_userdata() -> Dictionary<String, String>
    {
        var userid = UserModel.get_uuid()
        let data = db.query("SELECT * FROM userdata WHERE userid='\(userid)'")
        var row = data[0]
        var maxnum:Int = row["maxnum"]!.integer
        var dimension:Int = row["dimension"]!.integer
        var red:Double = row["red"]!.asDouble
        var green:Double = row["green"]!.asDouble
        var blue:Double = row["blue"]!.asDouble
        var alpha:Double = row["alpha"]!.asDouble
        
        
        var dic:Dictionary<String, String> = ["maxnum": "\(maxnum)",
            "dimension": "\(dimension)",
            "red": "\(red)",
            "green": "\(green)",
            "blue": "\(blue)",
            "alpha": "\(alpha)"];
        return dic;
    }
    //保存维度数据
    func save_dimension(dimension:Int)
    {
        var userid = UserModel.get_uuid()
        db.execute("UPDATE userdata SET dimension=\(dimension) WHERE userid='\(userid)'")
    }
    //保存过关数字数据
    func save_maxnum(maxnum:Int)
    {
        var userid = UserModel.get_uuid()
        db.execute("UPDATE userdata SET maxnum=\(maxnum) WHERE userid='\(userid)'")
    }
    //保存颜色数据
    func save_color(backgroundColor:UIColor)
    {
        var cicolor:CIColor!
        cicolor = CIColor(color: backgroundColor)
        var red = cicolor.red()
        var green = cicolor.green()
        var blue = cicolor.blue()
        var alpha = cicolor.alpha()
        var userid = UserModel.get_uuid()

        db.execute("UPDATE userdata SET red=\(red), green=\(green), blue=\(blue), alpha=\(alpha) WHERE userid='\(userid)'")
    }
    
    deinit
    {
       // db.closeDatabase()
    }
}