//
//  bridge.h
//  SwiftInAction-006-001
//
//  Created by zhihua on 14-7-8.
//  Copyright (c) 2014年 ucai. All rights reserved.
//


//这个文件需要在项目target的Build Settings里被Swift编译器引用
//具体位置在Swift Compiler - Code generation/Object-C Bridging Header

//KKColorsSchemeType.h已经包含在KKColorListViewController.h
#import "KKColorListViewController.h"
#import "KKColor.h"

