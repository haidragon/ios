//
//  ViewController.swift
//  SwiftInAction-006-005
//
//  Created by zhihua on 14-7-8.
//  Copyright (c) 2014年 ucai. All rights reserved.
//

import UIKit

//主视图
class ViewController: UIViewController, KKColorListViewControllerDelegate {
    
    //Object-C编写的颜色选择器视图
    var viewColor:KKColorListViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //初始化颜色选择面板
        //这个颜色选择面板是用OC开发，我们导入头文件后就能在Swift里调用了
        viewColor = KKColorListViewController(schemeType:KKColorsSchemeType.Crayola)
        //此类实现了颜色选择面板的代理协议，并重载了选择颜色和关闭2个回调函数
        viewColor.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //点击选择背景色的事件操作
    @IBAction func selColor(sender: AnyObject) {
        //显示颜色选择面板
        self.presentViewController(viewColor, animated: true, completion:nil)
    }
    
    //选择颜色后回调
    func colorListController(controller:KKColorListViewController,  didSelectColor color:KKColor)
    {
        //关闭颜色选择器视图
        viewColor.dismissViewControllerAnimated(true, completion:nil)
        //设置当前视图的背景颜色为用户选择的颜色
        self.view.backgroundColor = color.uiColor()
    }
    //用户在颜色选择器视图里点击了关闭
    func colorListPickerDidComplete(controller:KKColorListViewController)
    {
        //只需要关闭颜色选择器视图
        viewColor.dismissViewControllerAnimated(true, completion:nil)
    }
    
    


}

