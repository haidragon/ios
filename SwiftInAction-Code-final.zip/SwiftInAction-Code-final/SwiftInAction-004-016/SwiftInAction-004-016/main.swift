//
//  main.swift
//  SwiftInAction-004-016
//
//  Created by wuxing on 14/7/31.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Simple
{
    var optionalValue:String?
    func print()
    {
        if optionalValue != nil
        {
            println(optionalValue)
            println(count(optionalValue!))

        }
    }
    
    func set()
    {
        //fatal error: unexpectedly found nil while unwrapping an Optional value
        //println(countElements(optionalValue!))

        self.optionalValue = "China"
    }
}

var s = Simple()
s.set()
s.print()

 