//
//  main.swift
//  SwiftInAction-003-026
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

//桃子类
/*class Peach
{
var leaves:Array<Leave>!     //叶子属性
var position:Position!   //生长位置属性
func photosynthesis(){} //光合作用方法
func grow(){}   //生长方法
func fruct(){}  //结果方法
func graft(){}  //嫁接方法
}*/
struct Position
    {
    var longtitue:Double = 0
    var latitue:Double = 0
}
struct Leave
{
    var color:String!
    init(color:String)
    {
        self.color = color
        println("\(color)叶子")
    }
}
//生物类
class Living
    {
    func grow(){
     println("生长中")
    }
}
//植物类
class Plant:Living
    {
    var leaves:Array<Leave>!     //叶子属性
    var position:Position!   //生长位置属性
    func photosynthesis(){
    println("光合作用中")
    } //光合作用方法
}
//水果类
class Fruit:Plant
    {
    func fruct(){
    println("结果中")
    }  //结果方法
}
//桃子类
class Peach:Fruit
    {
    override init()
    {
        super.init()
        super.leaves = Array(count:10,repeatedValue:Leave(color:"绿"))
        super.position = Position(longtitue: 138, latitue: 28)
    }
    func graft(){
        println("嫁接中")
    }  //嫁接方法
    
    func life()
    {
        self.grow()
        println("生长在(\(self.position.longtitue), \(self.position.latitue))处，长出了\(self.leaves.count)片叶子")
        self.photosynthesis()
        self.graft()
        self.fruct()
    }
}

var peach = Peach()
peach.life()



