//
//  vars.swift
//  SwiftInAction-004-007
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

//private var str = "Hello, World!"

class Student
{
    private var name = ""
    internal var age = 20
}