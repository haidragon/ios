//
//  main.swift
//  SwiftInAction-004-007
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

//println(str)
  
var student = Student()
//出错，因为在类中 name 是 private
//println(student.name)
//正常运行
println(student.age)