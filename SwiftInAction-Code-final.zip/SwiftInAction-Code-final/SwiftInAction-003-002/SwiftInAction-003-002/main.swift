//
//  main.swift
//  SwiftInAction-003-002
//
//  Created by wuxing on 14/7/22.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

//类定义
class Person
{
    //类属性
    var name:String
    var age:Int
    var sex:String
    
    //类构造函数
    init(name newName:String, age newAge:Int, sex newSex:String)
    {
        self.name = newName
        self.age = newAge
        self.sex = newSex
    }
    //类方法
    func say() -> String
    {
        return "我是：\( name) \( sex)，今年\( age)岁"
    }
    func run () -> String
    {
        return "\(name)在跑步"
    }
    func drive() -> String
    {
        return "\(name)在开车"
    }
}
//使用类初始化一个对象，传入具体的属性
var p = Person(name: "wuxing", age: 31, sex: "male")
//调用相应的类方法
println(p.say())
println(p.run())
println(p.drive())
        
