//
//  main.swift
//  SwiftInAction-002-005
//
//  Created by aba on 14-8-5.
//  Copyright (c) 2014年 aba. All rights reserved.
//

import Foundation


func addString(#sName: String,#sSex: String, sAge: String="20") -> String {
    return "Name is" + sName + "and sex is" + sSex + "and age is" + sAge
}

addString(sName:"lily",sSex:"girl", sAge:"18")

//函数指针
var addSome:(String,String,String)->String = addString
let anotheraddSome = addString

func MyFunction(sName:String,sScore:Int)->String{
    func CompScore(iScores:Int)->String{
    return String(iScores * 2)
    }
    var tmpa=""
    tmpa=CompScore(sScore)
    return "Name is"+sName+" and Score is "+tmpa
}

//数组为String类型，因此排序闭包为(String, String)->Bool类型的函数。
let names = ["Lily", "Anna", "Duty", "Poly", "Gray"]
func compareName(s1: String, s2: String) -> Bool {return s1 > s2}
var sortedArray = names.sorted(compareName)
//与compareName函数对应的闭包表达式版本的代码：
sortedArray = names.sorted({(s1: String, s2: String)->Bool in
        return s1 > s2
        })

var receiveArray1 = sorted(names,{s1, s2 in return s1 > s2})
println(receiveArray1)
var receiveArray2 = sorted(names,{return $0 > $1})
println(receiveArray2)
var receiveArray3=sorted(names,{return $0 > $1})
println(receiveArray3)

var tmpArray=sorted(names, >)
sortedArray = names.sorted(>)

var opsortedArray = sorted(names){return $0 > $1}

var numberArray = [3,45, 23, 523, 2]
let numbers = numberArray.map({
    (number:Int) -> Int in
    let result = 3 * number
    return result
    })
println(numbers)

