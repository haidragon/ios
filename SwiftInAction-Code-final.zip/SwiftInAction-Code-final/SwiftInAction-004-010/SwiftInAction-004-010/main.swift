//
//  main.swift
//  SwiftInAction-004-010
//
//  Created by wuxing on 14/7/30.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

extension String
{
    
    subscript(start:Int, length:Int) -> String
        {
        get{
            return (self as NSString).substringWithRange(NSRange(location: start, length: length))
        }
        set{
            var tmp = Array(self)
            var s = ""
            var e = ""
            for (idx, item) in enumerate(tmp) {
                if(idx < start)
                {
                    s += "\(item)"
                }
                if(idx > start + length)
                {
                    e += "\(item)"
                }
            }
            self = s + newValue + e
        }
    }
    subscript(index:Int) -> String
        {
        get{
            return String(Array(self)[index])
        }
        set{
            var tmp = Array(self)
            tmp[index] = Array(newValue)[0]
            self = ""
            for (idx, item) in enumerate(tmp) {
                self += "\(item)"
            }
        }
    }
}

var str = "China Beijing"
println(str[6,7])
println(str[6])

str[6,2] = "Hunan"
str[6] = "F"

println(str[0,15])



