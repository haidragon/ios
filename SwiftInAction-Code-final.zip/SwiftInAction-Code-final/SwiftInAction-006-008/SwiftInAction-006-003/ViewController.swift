//
//  ViewController.swift
//  SwiftInAction-006-003
//
//  Created by zhihua on 14-7-9.
//  Copyright (c) 2014年 ucai. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var label:UILabel = UILabel(frame:CGRectMake(100, 100,300,100));
        label.text = "输出结果在控制台"
        self.view.addSubview(label)
        //测试Swift调用Object的XML库功能
        testXML()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func testXML() {
        //获取xml文件路径
        var path = NSBundle.mainBundle().pathForResource("users", ofType:"xml")
        //获取xml文件内容
        var xmlData = NSData(contentsOfFile:path!)
    

        
        /*
         通过另一个OC库DDXML解析，方法基本相同
        */
        
        
        //构造XML文档
        var doc = DDXMLDocument(data: xmlData, options:0, error:nil)
        
        //利用XPath来定位节点（XPath是XML语言中的定位语法，类似于数据库中的SQL功能）
        var users = doc.nodesForXPath("//User", error:nil) as! [DDXMLElement]
        for user in users {
            let uid = user.attributeForName("id").stringValue()
            //DDXMLElementAdditions提供了elementForName获取单个节点，不用获取数组了
            let uname = user.elementForName("name").stringValue()
            //获取tel节点的子节点
            let telElement = user.elementForName("tel") as DDXMLElement
            let mobile = (telElement.elementForName("mobile") as DDXMLElement).stringValue()
            let home = (telElement.elementForName("home") as DDXMLElement).stringValue()
            println("User: uid:\(uid),uname:\(uname),mobile:\(mobile),home:\(home)")
        }
        
        
    }

}

