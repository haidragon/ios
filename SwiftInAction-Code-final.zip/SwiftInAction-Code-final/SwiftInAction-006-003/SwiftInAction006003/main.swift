//
//  main.swift
//  SwiftInAction006003
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
var dog = Dog()
var pig = Pig()
var tortoise = Tortoise()
var piegon = Piegon()

var animals:Array<Animal> = [dog, pig, tortoise, piegon]

for animal in animals
{
   animal.run()
}

var coutries:NSArray = ["China", "America", "USA"]
for country in coutries
{
    println(country)
}

var zoo = Zoo()
zoo.contest()