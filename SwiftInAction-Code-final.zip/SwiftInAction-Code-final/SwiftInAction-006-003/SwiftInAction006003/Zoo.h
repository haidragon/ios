//
//  Zoo.h
//  SwiftInAction006003
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Zoo : NSObject

-(id)init;
-(void)contest;

@end