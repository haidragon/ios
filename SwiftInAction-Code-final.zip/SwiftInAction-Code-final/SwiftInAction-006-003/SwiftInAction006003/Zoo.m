//
//  Zoo.m
//  SwiftInAction006003
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "Zoo.h"
#include "SwiftInAction006003-Swift.h"

@implementation Zoo
//无参数构造函数
-(id) init
{
    if(self = [super init])
    {
    }
    return self;
}

-(void)contest
{
    Pig *pig = [[Pig alloc]init];
    Dog *dog = [[Dog alloc]init];
    Tortoise *tortoise = [[Tortoise alloc]init];
    Piegon *piegon = [[Piegon alloc]init];
    
    NSArray *animals = [[NSArray alloc] initWithObjects:pig, dog, tortoise,piegon,nil];
    id obj;
    for(int i = 0; i < [animals count]; i++)
    {
        obj = [animals objectAtIndex:i];
        [obj run];
    }
}

@end

