//
//  main.swift
//  SwiftInAction-003-006
//
//  Created by wuxing on 14/7/23.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")
class Deposit{
    init()
    {
        println("output init at Deposit")
    }
}
class Person{
    var name:String!
    lazy var money:Deposit=Deposit()
}
class Student{
    var name:String!
    var classno:Int!
    var from:String!
    let country:String = "中国"
    let friend:Person=Person()
}

var student = Student()
student.name = "wuxing"
student.classno = 1
student.from = "hunan"
//下面这一行会出错
//student.country="中华人民共和国"
student.friend.name = "xiaoming"
println("name=\(student.name)")
println("classno=\(student.classno)")
println("from=\(student.from)")
println("friend name=\(student.friend.name)")
//println(student.friend.money)