//
//  main.swift
//  SwiftInAction-003-016
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

class Connection:NilLiteralConvertible{
    internal required init(nilLiteral:()) {
    }
    class func convertFromNilLiteral() -> Self
    {
        return self(nilLiteral:())
    }
    class func connect() -> Connection
    {
        println("建立连接")
        return Connection(nilLiteral:())
    }
    
    func close()
    {
        println("关闭连接")
    }
    
}
class DBClass:NilLiteralConvertible
{
    var conn:Connection
    class func convertFromNilLiteral() -> Self
     {
        return self(nilLiteral:())
    }
    required init(nilLiteral: ()){
        self.conn = nil
    }
    init(build:Bool){
        self.conn = Connection.connect()
    }
    
    deinit{
        self.conn.close()
        self.conn = nil
    }
}

var db = DBClass(build: true)
db = nil