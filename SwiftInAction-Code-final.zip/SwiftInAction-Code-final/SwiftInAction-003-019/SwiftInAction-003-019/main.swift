//
//  main.swift
//  SwiftInAction-003-019
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

class Student{
    var score:[Int] = {
    var scores:[Int] = Array()
    for m in 0...3{
    scores.append(m)
    }
    return scores
    }()
}

println(Student().score)