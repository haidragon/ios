//
//  main.swift
//  SwiftInAction-003-018
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Rect
{
    var width:Int;
    var height:Int;
    init(width:Int, height:Int)
    {
        self.width = width
        self.height = height
    }
    convenience init(width w:Int, h:Int)
    {
        self.init(width:w, height:h)
    }
    convenience init(w:Int, h:Int)
    {
        self.init(width:w, height:h)
    }
    
    func getArea()->Int
    {
        return self.width * height
    }
}

var rect = Rect(w: 10,h: 20)
println(rect.getArea())
rect = Rect(width: 20,height: 20)
println(rect.getArea())
rect = Rect(width: 20,h: 30)
println(rect.getArea())

