//
//  main.swift
//  SwiftInAction-003-004
//
//  Created by wuxing on 14/7/23.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

class Student{
    var name:String!
    var classno:Int!
    var from:String!
    let country:String="China"
}

var student = Student()
student.name = "wuxing"
student.classno = 1
student.from = "hunan"
println("name=\(student.name)")
println("classno=\(student.classno)")
println("from=\(student.from)")