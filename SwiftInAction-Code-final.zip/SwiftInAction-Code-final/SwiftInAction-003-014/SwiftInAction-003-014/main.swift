//
//  main.swift
//  SwiftInAction-003-014
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation


class Rect
{
    var width:Int;
    var height:Int;
    init(w:Int, h:Int)
    {
        width = w;
        height = h;
    }
   
    func getArea()->Int
    {
        return self.width * height
    }
}

var rect = Rect(w: 10,h: 20)
println(rect.getArea())

