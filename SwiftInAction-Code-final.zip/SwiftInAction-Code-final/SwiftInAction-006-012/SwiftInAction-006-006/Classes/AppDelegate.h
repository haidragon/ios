//
//  AppDelegate.h
//  SwiftInAction-006-006
//
//  Created by zhihua on 14-7-12.
//  Copyright ucai 2014年. All rights reserved.
//
// -----------------------------------------------------------------------

#import "cocos2d.h"

@interface AppDelegate : CCAppDelegate
@end
