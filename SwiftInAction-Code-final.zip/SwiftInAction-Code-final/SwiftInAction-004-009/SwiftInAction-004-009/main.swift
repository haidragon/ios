//
//  main.swift
//  SwiftInAction-004-009
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")
//var student = Student()
