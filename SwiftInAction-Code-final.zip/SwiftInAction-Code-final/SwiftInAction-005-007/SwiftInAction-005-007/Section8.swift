//
//  Section8.swift
//  SwiftInAction-005-007
//
//  Created by krisley on 14-9-15.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section8: NSObject{
    func totalTest(){
        part5()
    }
    
    func part1(){
        let string = "Hello world"
        // 将字符串进行UTF8编码成NSData
        let utf8EncodeData = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        
        // init(data data: NSData!) 分配一块新的内存空间，并用另一个NSData对象来初始化
        let withData = NSData(data:utf8EncodeData!)
        
        let url = NSURL(string:"https://www.google.com.hk/intl/zh-CN/policies/terms/regional.html")
        // init(contentsOfURL aURL: NSURL!) 分配一块新的内存空间，并用URL对应地址的内容数据来初始化NSData
        let withContentURL = NSData(contentsOfURL:url!)
        
        let filePath = NSBundle.mainBundle().pathForResource("testFile", ofType: "txt")
        // init(contentsOfFile path: String!) 分配一块新的内存空间，并用文件路径所对应的内容数据来初始化NSData
        let withPath = NSData(contentsOfFile:filePath!)
    }
    
    func part2(){
        let string = "Hello world"
        // 将字符串进行UTF8编码成NSData
        let utf8EncodeData:NSData! = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        println("utf8EncodeData:\(utf8EncodeData)")
        let bytesData = NSData(bytes: string.cStringUsingEncoding(NSUTF8StringEncoding)!, length: string.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))
        println("bytesData:\(bytesData)")
        let utf8EqualBytes = utf8EncodeData.isEqualToData(bytesData)
        println("utf8 Equal Bytes: \(utf8EqualBytes)")
        let utf8CompareByptes = utf8EncodeData === bytesData
        println("utf8 Compare Bytes: \(utf8CompareByptes)")
        
        // var bytes: COpaquePointer { get } 只读，获取指向NSData对象内容的指针，长度为0时返回nil
        var bytes = utf8EncodeData.bytes
        let length = utf8EncodeData.length
        var stringFromData = NSString(bytes: bytes, length: utf8EncodeData.length, encoding: NSUTF8StringEncoding)
        println("string from data: \(stringFromData)")
        
        var yt = [UInt8](count: utf8EncodeData.length, repeatedValue: 0)
        utf8EncodeData.getBytes(&yt, length: utf8EncodeData.length)
        for c in yt {
            let s = UnicodeScalar(Int(c)).escape(asASCII:true)
            println("\(c):\(s)")
        }
        // var description: String! { get } 只读，获取NSData对象的描述内容，默认为内容数据的16进制编码
        let descrition = utf8EncodeData.description
        println("descrition: \(descrition)")
        
        let newData = NSData(data:utf8EncodeData)
        
        // isEqualToData(_ otherData: NSData!) -> Bool 对比两个NSData对象的长度及每字节的数据是否相同，如果内容完全一致，返回true；否则返回false
        let isEqualToData:Bool = utf8EncodeData.isEqualToData(newData)
        let isEqual:Bool = utf8EncodeData === newData
        println("utf8EncodeData equal to newData: \(isEqualToData) ")
        println("utf8EncodeData === newData: \(isEqual) ")
    }
    
    func part3(){
        let string = "Hello world"
        
        // 将字符串进行UTF8编码成NSData
        let utf8EncodeData:NSData! = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        // 将NSData进行base64编码
        let base64EncodedString = utf8EncodeData.base64EncodedStringWithOptions(NSDataBase64EncodingOptions(0))
        println("encodedString: \(base64EncodedString)")
        
        // 将base64字符串转换成NSData
        let base64EncodedData = NSData(base64EncodedString:base64EncodedString,options:NSDataBase64DecodingOptions(0))
        // 对NSData数据进行UTF8解码
        let stringWithDecode = NSString(data: base64EncodedData!, encoding: NSUTF8StringEncoding)
        println("base64String: \(stringWithDecode)")
    }
    
    func part4(){
        let string = "将字符串进行UTF8编码成NSData"
        // 将字符串进行UTF8编码成NSData
        let utf8EncodeData:NSData! = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        var pathArray:Array = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory,NSSearchPathDomainMask.UserDomainMask,true)
        var defaultPath = pathArray[0] as! String
        let textPath = defaultPath + "/text.txt"
        println("textPath: \(textPath)")
        
        // writeToFile(_ path: String!,atomically atomically: Bool) -> Bool
        // 将数据保存到APP的沙箱Documents目录下，文件名是text.txt，并将保存结果返回
        let result = utf8EncodeData.writeToFile(textPath,atomically:true)
        println("write to file result: \(result)")
    }
    
    func part5(){
        var mutableData = NSMutableData(capacity:10)
        println("mutableData length: \(mutableData!.length)，content: \(mutableData)")
        
        var mutableData2 = NSMutableData(length:10)
        println("mutableData2 length: \(mutableData2!.length)，content: \(mutableData2)")
        
        mutableData2!.increaseLengthBy(3)
        println("mutableData2 length: \(mutableData2!.length)，content: \(mutableData2)")
        
        mutableData2!.length = 3
        println("mutableData2 length: \(mutableData2!.length)，content: \(mutableData2)")
        mutableData2!.length = 5
        println("mutableData2 length: \(mutableData2!.length)，content: \(mutableData2)")
    }
}