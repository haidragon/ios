//
//  main.swift
//  SwiftInAction-004-020
//
//  Created by wuxing on 14/7/31.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
func swapInts(inout a:Int, inout b:Int)
{
    var tmp = a
    a = b
    b = tmp
}
func swapStrs(inout a:String, inout b:String)
{
    var tmp = a
    a = b
    b = tmp
}
func swapT<T>(inout a:T, inout b:T)
{
    var tmp = a
    a = b
    b = tmp
}

var a:Double = 2.0
var b:Double = 3.0
swapT(&a, &b)

struct Student{
    var no:Int
}
var sa = Student(no: 100)
var sb = Student(no:101)
swapT(&sa, &sb)

