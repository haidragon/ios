//
//  main.swift
//  SwiftInAction-004-015
//
//  Created by wuxing on 14/7/30.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
protocol vehicle
{
    func drive() //驾驶方法
}

class Motor:vehicle
{
    var brand = ""
    init(brand:String)
    {
        self.brand = brand
    }
    func start() //启动方法
    {
        println("\(self.brand)启动")
    }
    func drive()
    {
        println("\(self.brand)驾驶")
    }
}
class Maker
{
    var name:String=""
    var from:String=""
    func printMaker()
    {
        println("制造商来自\(self.from)的\(self.name)")
    }
}
class Audi:Motor
{
    var maker:Maker
    init()
    {
        self.maker = Maker()
        self.maker.name = "奥迪"
        self.maker.from = "德国"
        super.init(brand: "Audi")
    }
   
}
var audi = Audi()
audi.start()
audi.drive()
audi.maker.printMaker()
