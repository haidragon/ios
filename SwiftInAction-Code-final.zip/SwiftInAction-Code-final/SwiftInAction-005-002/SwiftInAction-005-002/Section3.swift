//
//  Section3.swift
//  SwiftInAction-005-002
//
//  Created by krisley on 14-9-13.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section3: NSObject{
    func totalTest(){
        part1Seg1()
    }
    
    //MARK: - 以下对应5.3.1节代码

    func part1Seg1(){
        let string="Hello World"
        println(string.lowercaseString);
    }
    
    func part1Seg2(){
        var string = NSString(string:"123")
        var num=(string as String).toInt()
        //        var num = string.toInt() // 编译错误，NSString does not have a member named toInt
    }
    
    //MARK: - 以下对应5.3.2节代码
    
    func part2Seg1(){
        let string:NSString = "Apple,iOS,Swift,String"
        let subStringsArray = string.componentsSeparatedByString(",")
        for sub : AnyObject in subStringsArray {
            println(sub)
        }
    }
    
    func part2Seg2(){
        let string:NSString = "Apple,iOS;Swift;String"
        let subStringsArray = string.componentsSeparatedByCharactersInSet(NSCharacterSet(charactersInString:",;"))
        for sub: AnyObject in subStringsArray {
            println(sub)
        }
    }

    func part2Seg3(){
        let comment:NSString = "Hello, world! Welcome to Earth."
        println(comment.substringFromIndex(14))
        println(comment.substringToIndex(13))
        println(comment.substringWithRange(NSMakeRange(14,10)))
    }
    
    //MARK: - 以下对应5.3.3节代码
    
    func part3Seg1(){
        let string:NSString = "Apple;iOS,Swift;String,NSMutableString"
        let rangeForStr = string.rangeOfString("String")
        println("\(rangeForStr): \(string.substringWithRange(rangeForStr))")
        let rangeForStr2 = string.rangeOfString("Cocoa")
        if rangeForStr2.location==NSNotFound {
            println("not found")
        } else {
            println(rangeForStr2)
        }
    }
    
    func part3Seg2(){
        let string:NSString = "Apple;iOS,Swift;String,NSMutableString"
        let rangeForStr = string.rangeOfString("string", options:NSStringCompareOptions.CaseInsensitiveSearch)
        println("\(rangeForStr): \(string.substringWithRange(rangeForStr))")
    }
    
    func part3Seg3(){
        let string:NSString = "Apple;iOS,Swift;String,NSMutableString"
        let rangeForStr = string.rangeOfString("String", options:NSStringCompareOptions.BackwardsSearch)
        println("\(rangeForStr): \(string.substringWithRange(rangeForStr))")
    }
    
    
}