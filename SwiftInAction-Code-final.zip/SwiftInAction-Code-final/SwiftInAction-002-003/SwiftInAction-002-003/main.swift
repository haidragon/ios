//
//  main.swift
//  SwiftInAction-002-003
//
//  Created by aba on 14-8-3.
//  Copyright (c) 2014年 aba. All rights reserved.
//

import Foundation
//由于字符集显示的问题，这里显示不出animal这个字符，建议大家下载本书源码查看本节代码示例
let animalString = "a：🐒"
for codeUnit in animalString.utf8 {   //获取UTF-8字符码位(Unicode Scalars)
    println("\(codeUnit) ")
}
// 97 239 188 154 240 159 144 146

for codeUnit in animalString.utf16 { //获取UTF-8字符码位(Unicode Scalars)
    println("\(codeUnit)")
}
// 97 65306 55357 56338

for scalar in animalString.unicodeScalars {
    println("\(scalar.value)")
}
// 97 65306 128018


