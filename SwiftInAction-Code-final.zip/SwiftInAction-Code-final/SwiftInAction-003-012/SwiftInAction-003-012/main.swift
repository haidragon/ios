//
//  main.swift
//  SwiftInAction-003-012
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Rect
{
    private struct swidth{ static var width:Int=0 }
    internal class var width:Int
        {
        get { return swidth.width }
        set { swidth.width = newValue }
    }
    private struct sheight{ static var height:Int=0 }
    internal class var height:Int
        {
        get { return sheight.height }
        set { sheight.height = newValue }
    }
    
    class func setSize(w:Int, height:Int)
    {
        Rect.width = w
        Rect.height = height
    }
    
    class func getArea()->Int
    {
        return width * height
    }
}
/*
Rect.width = 10
Rect.height = 20*/
Rect.setSize(10,height: 20)
println(Rect.getArea())

