//
//  main.swift
//  SwiftInAction-003-001
//
//  Created by wuxing on 14/7/21.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")




enum GameResult
{
    case None
    case Fail
    case Success
}
//1、	开始游戏
func beginGame()
{
}
//2、	绘制地图
func drawMap()
{
}
//3、	闪现新数字
func genNumber()
{
}
//4、	响应滑动
func responseGesture()
{
}
//5、	移动数字
func moveNumber()
{
}
//6、	合并数字
func mergeNumber()
{
}
//7、	检测结果
func testResult() -> GameResult
{
    return GameResult.Success
}
//9、	结束游戏提示
func gameOver(ret:GameResult)
{
    
}
var ret:GameResult
do
{
        beginGame()
        drawMap()
        genNumber()
        responseGesture()
        moveNumber()
        mergeNumber()
        ret = testResult()
}while(ret == GameResult.None)
gameOver(ret)
