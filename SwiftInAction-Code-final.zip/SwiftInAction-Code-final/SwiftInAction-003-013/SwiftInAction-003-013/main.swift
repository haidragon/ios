//
//  main.swift
//  SwiftInAction-003-013
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Rect
{
    var width:Int
    var height:Int
    init()
    {
        width = 0;
        height = 0;
    }
    
    func setSize(w:Int, height:Int)
    {
        width = w
        self.height = height
    }
    
    func getArea()->Int
    {
        return self.width * height
    }
}

var rect = Rect()
rect.setSize(10,height: 20)
println(rect.getArea())