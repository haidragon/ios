//
//  main.swift
//  SwiftInAction-004-014
//
//  Created by wuxing on 14/7/30.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

//
//  main.swift
//  SwiftInAction-004-013
//
//  Created by wuxing on 14/7/30.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
protocol Animal
{
    func move()
}

protocol Bird:Animal
    {
    func song()
}
class Chiken:Bird{
        func song()
    {
        println("母鸡咯咯")
        }
        func move()
    {
    println("母鸡走")
        }
}
class Pegion:Bird
            {
            func song()
        {
            println("鸽子咕咕")
            }
            func move()
    {
            println("鸽子飞")
            }
}
class Crow:Bird
            {
            func song()
        {
            println("乌鸦呱呱")
            }
            func move()
    {
        println("乌鸦翔")
            }
}
class Duck:Bird
    {
    func song()
{
    println("鸭子嘎嘎")
    }
    func move()
{
                println("鸭子踱")
    }
}
class Sparrow:Bird
            {
            func song()
        {
            println("麻雀唧唧")
            }
            func move()
            {
                println("麻雀跳")
            }
}
class Swallow:Bird
        {
        func song()
    {
        println("燕子啾啾")
        }
        func move()
            {
                println("燕子跑")
        }
}
var birds:Array<Bird> = [Chiken(), Pegion(), Crow(), Duck(), Sparrow(), Swallow()]
for bird in birds
{
    bird.song()
    bird.move()
}
