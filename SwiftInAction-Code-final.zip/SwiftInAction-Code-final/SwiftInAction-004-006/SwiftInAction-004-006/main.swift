//
//  main.swift
//  SwiftInAction-004-006
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

infix operator  + { associativity left precedence 120 }
infix operator  * { associativity left precedence 100 }


let x = 3 * 3 + 4 * 5 + 9

println(x)