//
//  main.swift
//  SwiftInAction-003-010
//
//  Created by wuxing on 14/7/21.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Teacher
{
    var classno:Int = 0
    var defined = false
    var from:String = ""
    var name:String = ""
    private struct scountry{ static var country:String="中国" }
    internal class var country:String
    {
        get { return scountry.country }
        set { scountry.country = newValue }
    }
}
Teacher.country = "美国"
//这样输出不会出错，因为在 Teacher 类中， country 是类属性
println(Teacher.country)
