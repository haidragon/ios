//
//  Section9.swift
//  SwiftInAction-005-008
//
//  Created by krisley on 14-9-15.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section9: NSObject{
    func totalTest(){
        part6Seg1()
    }
    
    func part2(){
        let path = NSBundle.mainBundle().pathForResource("testFile",ofType:"txt")
        println(path)
        
        let tempDirectory = NSTemporaryDirectory()
        //获取当前用户域下的Document目录
        let directories =
        NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)
    }
    
    //MARK: - 以下为5.9.3小节代码
    func part3Seg2(){
        let mutabableURL = NSURL(scheme:"http",host:"swiftinaction.com",path:"/sayHello/toChinese")
        println("mutabableURL = \(mutabableURL)")
        let emptyHostURL = NSURL(scheme:"file",host:nil,path:"/sayHello/toChinese")
        println("emptyHostURL = \(emptyHostURL)")
        
        let baseURL = NSURL(string: "file:///path/to/web_root/")
        let url = NSURL(string: "folder/file.html", relativeToURL: baseURL)
        let absoluteURL = url!.absoluteURL
        println("absolute URL = \(absoluteURL)")
        let string = NSURL(string:"folder/file.html")
        let stringAbsoluteURL = string!.absoluteURL
        println("path = \(stringAbsoluteURL)")
        
        let complateString = "http://swiftinaction.com/中文字符串/hello world"
        let complateURL = NSURL(string:complateString)
        println("complateURL: \(complateURL!.description)")
        
        let convertString = complateString.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)
        let convertedURL = NSURL(string:convertString!)
        println("convertedURL: \(convertedURL)")
        
        let path = NSURL.fileURLWithPath("/sayHello")
        println("path:\(path)")
        
        let pathDirectory = NSURL.fileURLWithPath("/sayHello",isDirectory:true)
        println("pathDirectory:\(pathDirectory)")
    }
    
    func part3Seg3(){
        let url = NSURL(string: "http://swiftinaction.com:8080/sayHello/toChinese?name=ley#atMorning")
        println("absolute string: \(url!.absoluteString!)")
        println("fileSystemRepresentation: \(url!.fileSystemRepresentation)")
        println("host: \(url!.host!)")
        println("scheme: \(url!.scheme!)")
        println("port: \(url!.port!)")
        println("query: \(url!.query!)")
        println("fragment: \(url!.fragment!)")
        println("lastPathComponent: \(url!.lastPathComponent)")
        println("path: \(url!.path!)")
        println("pathComponents: \(url!.pathComponents)")
        println("relativePath: \(url!.relativePath!)")
        println("----------")
        let png = NSURL(string:"http://ley:password@swiftinaction.com/sayHello/withEmoji/happy.png")
        println("absolute string: \(png!.absoluteString!)")
        println("pathExtension: \(png!.pathExtension)")
        println("user: \(png!.user!)")
        println("password: \(png!.password!)")
    }
    
    func part3Seg4(){
        let fileURL = NSBundle.mainBundle().URLForResource("picture",withExtension:"jpg")
        let fileURLReachable = fileURL?.checkResourceIsReachableAndReturnError(nil)
        println("fileURLReachable: \(fileURLReachable)")
        
//        let webURL = NSURL(string:"http://www.rfc-editor.org/info/rfc1808")
//        println("is fileURL: \(webURL.fileURL)")
//        println("is fileURL: \(fileURL?.fileURL)")
        
        let webURL = NSURL(string: "http://swiftinaction.com/sayHello")!
        println("webURL: \(webURL)")
        let appendURL = webURL.URLByAppendingPathComponent("toLey")
        println("appendURL: \(appendURL)")
        let appendDirURL = webURL.URLByAppendingPathComponent("toChinese",isDirectory:true)
        println("appendDirURL: \(appendDirURL)")
        
        let appendExtensionToFile = webURL.URLByAppendingPathExtension("png")
        println("appendExtensionToFile: \(appendExtensionToFile)")
        let appendExtensionToDir = appendDirURL.URLByAppendingPathExtension("png")
        println("appendExtensionToDir: \(appendExtensionToDir)")
        
        let deleteLastPath = webURL.URLByDeletingLastPathComponent
        println("deleteLastPath: \(deleteLastPath)")
        let deleteExtension = appendExtensionToFile.URLByDeletingPathExtension
        println("deleteExtension for png: \(deleteExtension)")
    }
    
    func part3Seg5(){
        let component = NSURLComponents(string: "http://swiftinaction.com/sayHello")!
        component.password = "password"
        component.password = "password"
        component.port = 110
        component.query = "toName=ley"
        component.scheme = "https"
        component.fragment = "atMorning"
        component.path = "/加油/say Hello"
        println("url: \(component.URL)")
        println("path: \(component.percentEncodedPath)")
        println("path: \(component.path)")
    }
    
    //MARK: - 以下为5.9.4小节代码
    func part4Seg1(){
        // 获得NSFileManager共享实例
        let manager = NSFileManager.defaultManager()
        
        // 获得当前用户域下的Library/Application Support目录路径
        let urlsForSuppotDirectory = manager.URLsForDirectory(NSSearchPathDirectory.ApplicationSupportDirectory,inDomains:NSSearchPathDomainMask.UserDomainMask)
        println("urlsForSuppotDirectory: \(urlsForSuppotDirectory)")
        
        // 获得当前用户域下Documents目录路径
        let urlForDocument = manager.URLForDirectory(NSSearchPathDirectory.DocumentDirectory,inDomain:NSSearchPathDomainMask.UserDomainMask,appropriateForURL:nil,create:true,error:nil)
        println("urlForDocument: \(urlForDocument)")
    }
    
    func createFile(name:String,fileBaseUrl:NSURL){
        let manager = NSFileManager.defaultManager()
        var error:NSErrorPointer = nil
        
        let file = fileBaseUrl.URLByAppendingPathComponent(name)
        println("file: \(file)")
        let exist = manager.fileExistsAtPath(file.path!)
        if !exist {
            let data = NSData(base64EncodedString:"aGVsbG8gd29ybGQ=",options:.IgnoreUnknownCharacters)
            let createSuccess = manager.createFileAtPath(file.path!,contents:data,attributes:nil)
            println("create item success: \(createSuccess)")
        }
    }
    
    func createFolder(name:String,baseUrl:NSURL){
        let manager = NSFileManager.defaultManager()
        var error:NSErrorPointer = nil
        let folder = baseUrl.URLByAppendingPathComponent(name, isDirectory: true)
        println("folder: \(folder)")
        let exist = manager.fileExistsAtPath(folder.path!)
        if !exist {
            let createSuccess = manager.createDirectoryAtURL(folder, withIntermediateDirectories: true, attributes: nil, error: error)
            println("create folder success: \(createSuccess)")
        }
    }
    
    func part4Seg2(){
        let manager = NSFileManager.defaultManager()
        let urlForDocument = manager.URLsForDirectory( NSSearchPathDirectory.DocumentDirectory, inDomains:NSSearchPathDomainMask.UserDomainMask)
        let url = urlForDocument[0] as! NSURL
        var error:NSErrorPointer = nil
        //在文档目录下新建几个文件：test.txt，folder目录，及folder目录下的new.txt文件。
        createFile("test.txt", fileBaseUrl: url)
        createFolder("folder", baseUrl: url)
        createFile("folder/new.txt", fileBaseUrl: url)
        
        let contentsOfPath = manager.contentsOfDirectoryAtPath(url.path!, error: error)
        println("contentsOfPath: \(contentsOfPath)")
        
        let contentsOfURL = manager.contentsOfDirectoryAtURL(url, includingPropertiesForKeys: nil, options: NSDirectoryEnumerationOptions.SkipsHiddenFiles, error: error);
        println("contentsOfURL: \(contentsOfURL)")
        
        let enumeratorAtPath = manager.enumeratorAtPath(url.path!)
        println("enumeratorAtPath: \(enumeratorAtPath?.allObjects)")
        
        let enumeratorAtURL = manager.enumeratorAtURL(url, includingPropertiesForKeys: nil, options: NSDirectoryEnumerationOptions.SkipsHiddenFiles, errorHandler:nil)
        println("enumeratorAtURL: \(enumeratorAtURL?.allObjects)")
        
        let subPaths = manager.subpathsAtPath(url.path!)
        println("subPaths: \(subPaths)")
    }
    
    func part4Seg3(){
        // 定位到用户文档目录，并创建test.txt文件，folder目录和folder下的new.txt文件。
        let manager = NSFileManager.defaultManager()
        let urlForDocument = manager.URLsForDirectory( NSSearchPathDirectory.DocumentDirectory, inDomains:NSSearchPathDomainMask.UserDomainMask)
        let url = urlForDocument[0] as! NSURL
        var error:NSErrorPointer = nil
        
        createFile("test.txt", fileBaseUrl: url)
        createFolder("folder", baseUrl: url)
        createFile("folder/new.txt", fileBaseUrl: url)
        
        let contentsOfURL = manager.contentsOfDirectoryAtURL(url, includingPropertiesForKeys: nil, options: NSDirectoryEnumerationOptions.SkipsHiddenFiles, error: error);
        // 将contentsOfURL[0]文件拷贝到文档目录根目录下的copyed.txt文件
        let srcUrl = url.URLByAppendingPathComponent("test.txt")
        println("srcUrl: \(srcUrl)")
        let toUrl = url.URLByAppendingPathComponent("copyed.txt")
        println("toUrl: \(toUrl)")
        
        let copyItemSuccess = manager.copyItemAtURL(srcUrl, toURL: toUrl, error: error)
        println("copyItemSuccess: \(copyItemSuccess)")
        var paths = manager.contentsOfDirectoryAtPath(url.path!, error: error)
        println("paths: \(paths)")
        
        // 删除文档根目录下的toUrl路径的文件（copyed.txt文件）
        let removeItemSuccess = manager.removeItemAtURL(toUrl, error: error)
        println("removeItemSuccess: \(removeItemSuccess)")
        paths = manager.contentsOfDirectoryAtPath(url.path!, error: error)
        println("paths: \(paths)")
        
        // 移动srcUrl中的文件（test.txt）到toUrl中（copyed.txt）
        let moveItemSuccess = manager.moveItemAtURL(srcUrl, toURL: toUrl, error: error)
        paths = manager.contentsOfDirectoryAtPath(url.path!, error: error)
        println("paths: \(paths)")
    }
    
    func part4Seg4(){
        let manager = NSFileManager.defaultManager()
        let urlsForDocDirectory = manager.URLsForDirectory(NSSearchPathDirectory.DocumentDirectory,inDomains:NSSearchPathDomainMask.UserDomainMask)
        let docPath:NSURL = urlsForDocDirectory[0] as! NSURL
        let displayName = manager.displayNameAtPath(docPath.path!)
        println("docPath displayName: \(displayName)")
        let file = docPath.URLByAppendingPathComponent("test.txt")
        println("file: \(file)")
        createFile("test.txt", fileBaseUrl: docPath)
        
        let readable = manager.isReadableFileAtPath(file.path!)
        println("readable: \(readable)")
        let writeable = manager.isWritableFileAtPath(file.path!)
        println("writeable: \(writeable)")
        let executable = manager.isExecutableFileAtPath(file.path!)
        println("executable: \(executable)")
        let deleteable = manager.isDeletableFileAtPath(file.path!)
        println("deleteable: \(deleteable)")
        
        let attributes = manager.attributesOfItemAtPath(file.path!,error:nil)
        println("attributes: \(attributes!)")
        
        let data = manager.contentsAtPath(file.path!)
        let copyURL = docPath.URLByAppendingPathComponent("copy.txt")
        let copycontentSuccess = manager.createFileAtPath(copyURL.path!,contents:data,attributes:nil)
        println("copy content success: \(copycontentSuccess)");
        let newFile = docPath.URLByAppendingPathComponent("new.txt")
        let copyItemSuccess = manager.copyItemAtURL(file,toURL: newFile,error: nil)
        println("copy item success: \(copyItemSuccess)")
        let removeItemSuccess = manager.removeItemAtURL(file,error: nil)
        println("remove item success: \(removeItemSuccess)")
        
        let contents = manager.contentsOfDirectoryAtPath(docPath.path!,error:nil)!
        println("contents: \(contents)")
        let count = contents.count
        if count > 1 {
            let path1 = docPath.path! + "/" + (contents[0] as! String)
            let path2 = docPath.path! + "/" + (contents[1] as! String)
            let equal = manager.contentsEqualAtPath(path1,andPath:path2)
            println("path1 contents isEqual path2: \(equal)")
        }
    }
    
    func part5(){
        let manager = NSFileManager.defaultManager()
        let urlsForDocDirectory = manager.URLsForDirectory(NSSearchPathDirectory.DocumentDirectory,inDomains:NSSearchPathDomainMask.UserDomainMask)
        let docPath:NSURL = urlsForDocDirectory[0] as! NSURL
        let file = docPath.URLByAppendingPathComponent("test.txt")
        let isExist = manager.fileExistsAtPath(file.path!)
        println("file is exist: \(isExist)")
        if !isExist {
            createFile("test.txt", fileBaseUrl: docPath)
        }
        var readHandler = NSFileHandle(forReadingFromURL:file,error:nil)!
        var data = readHandler.readDataToEndOfFile()
        var readString = NSString(data: data, encoding: NSUTF8StringEncoding)
        println("readString: \(readString)")
        let string = "添加一些文字到文件末尾"
        let appendedData = string.dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true)
        let writeHandler = NSFileHandle(forWritingToURL:file,error:nil)!
        writeHandler.seekToEndOfFile()
        writeHandler.writeData(appendedData!)
        readHandler = NSFileHandle(forReadingFromURL:file,error:nil)!
        data = readHandler.readDataToEndOfFile()
        readString = NSString(data: data, encoding: NSUTF8StringEncoding)
        println("readString: \(readString)")
    }
    
    func part6Seg1(){
        let mainBundle = NSBundle.mainBundle()
        let bundlePath = mainBundle.bundlePath
        let bundleURL = mainBundle.bundleURL
        let bundleRootFileURL = mainBundle.URLForResource("picture",withExtension:"jpg")
        let bundleRootFilePath = mainBundle.pathForResource("picture",ofType:"jpg")
        println(bundleRootFilePath)
        
        let bundleSubFileURL = mainBundle.URLForResource("sub_pic",withExtension:"jpg",subdirectory:"pictures/")
        let bundleSubFilePath = mainBundle.pathForResource("sub_pic",ofType:"jpg",inDirectory:"pictures/")
        
        let settingsUrl = mainBundle.URLForResource("Settings",withExtension:"bundle")
        let plistUrl = settingsUrl?.URLByAppendingPathComponent("Root.plist")
    }
}