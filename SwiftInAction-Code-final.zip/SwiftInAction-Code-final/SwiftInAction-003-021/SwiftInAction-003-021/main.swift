//
//  main.swift
//  SwiftInAction-003-021
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

//
//  main.swift
//  SwiftInAction-003-020
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

class SubString
{
    var str:String = ""
    init(str:String)
    {
        self.str = str;
    }
    subscript(start:Int, length:Int) -> String
    {
        get{
            return (str as NSString).substringWithRange(NSRange(location: start, length: length))
        }
        set{
            var tmp = Array(str)
            str = ""
            var s = ""
            var e = ""
            for (idx, item) in enumerate(tmp) {
                if(idx < start)
                {
                    s += "\(item)"
                }
                if(idx > start + length)
                {
                    e += "\(item)"
                }
            }
            str = s + newValue + e
        }
    }
    subscript(index:Int) -> String
    {
        get{
            return String(Array(str)[index])
        }
        set{
            var tmp = Array(str)
            tmp[index] = Array(newValue)[0]
            str = ""
            for (idx, item) in enumerate(tmp) {
                str += "\(item)"
            }
        }
    }
}

var str = SubString(str:"China Beijing")
println(str[6,7])
println(str[6])

str[6,2] = "Hunan"
str[6] = "F"

println(str[0,15])



