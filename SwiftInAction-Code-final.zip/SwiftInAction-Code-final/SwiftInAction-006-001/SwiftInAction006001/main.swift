//
//  main.swift
//  SwiftInAction006001
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

var cal = Calculator()

println(cal.add())
println(cal.sub())
println(cal.mul())
println(cal.div())
//-(id) initWithFirst:(int)first second:(int) second;
cal = Calculator(first: 20, second: 2);
println(cal.add())
println(cal.sub())
println(cal.mul())
println(cal.div())

