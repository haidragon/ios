//
//  MathUtil.h
//  SwiftInAction006001
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#import <Foundation/Foundation.h>
//定义计算器类
@interface Calculator : NSObject
@property (nonatomic, assign) int first;
@property (nonatomic, assign) int second;

//空构造函数
-(id) init;
//带参数的构造函数
-(id) initWithFirst:(int)first second:(int) second;

//加
-(int)add;
//减
-(int)sub;
//乘
-(int)mul;
//除
-(int)div;
@end
