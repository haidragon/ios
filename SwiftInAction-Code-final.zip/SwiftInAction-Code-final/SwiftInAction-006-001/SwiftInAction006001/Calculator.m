//
//  Calculator.m
//  SwiftInAction006001
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/Foundation.h>
#include "Calculator.h" 

@implementation Calculator
@synthesize first;
@synthesize second;
//无参数构造函数
-(id) init
{
    if(self = [super init])
    {
        self.first = 1;
        self.second = 1;
    }
    return self;
}
//有参数构造函数
-(id)initWithFirst:(int) newFirst second:(int) newSecond
{
    if(self = [super init])
    {
        self.first = newFirst;
        self.second = newSecond;
    }
    return self;
}
//加
-(int)add
{
    return self.first + self.second;
}
//减
-(int)sub
{
    return self.first - self.second;
}
//乘
-(int)mul
{
    return self.first * self.second;
}
//除
-(int)div
{
    return self.first / self.second;
}

@end