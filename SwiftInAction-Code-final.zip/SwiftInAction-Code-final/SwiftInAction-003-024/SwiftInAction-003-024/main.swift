//
//  main.swift
//  SwiftInAction-003-024
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

class People{
    var name=""
    init(name:String)
    {
        self.name = name
    }
}

struct Human{
    var name=""
    init(name:String)
    {
        self.name = name
    }
}

var xw = People(name: "xiaowang")
println(xw.name)
var p = xw;
p.name = "xiaoping"
println(xw.name)

var lm = Human(name: "liming")
println(lm.name)
var l = lm
l.name = "liliang"
println(lm.name)


