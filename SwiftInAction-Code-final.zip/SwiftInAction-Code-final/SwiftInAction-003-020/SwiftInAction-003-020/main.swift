//
//  main.swift
//  SwiftInAction-003-020
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")
class SubString
{
    var str:String = ""
    init(str:String)
    {
        self.str = str;
    }
    subscript(start:Int, end:Int) -> String
        {
        return (str as NSString).substringWithRange(NSRange(location: start, length: end))
    }
    subscript(index:Int) -> String
        {
        return String(Array(str)[index])
    }
}
var str = SubString(str:"China Beijing")
println(str[6,7])
println(str[6])






