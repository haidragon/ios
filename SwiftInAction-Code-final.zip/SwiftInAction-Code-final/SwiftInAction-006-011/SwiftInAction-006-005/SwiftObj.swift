//
//  SwiftObj.swift
//  SwiftInAction-006-005
//
//  Created by zhihua on 14-7-9.
//  Copyright (c) 2014年 ucai. All rights reserved.
//

import Foundation

class SwiftObj : NSObject {
    
    //内部属性
    var base: Int = 2
    
    override init() {
    }
    
    //提供给Object-C获取base属性
    func getBase(someArg: AnyObject) -> Int {
        println("Swift getBase: \(someArg)")
        return self.base
    }
    
}