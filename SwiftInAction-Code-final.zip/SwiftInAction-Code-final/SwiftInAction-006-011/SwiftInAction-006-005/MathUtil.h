//
//  MathUtil.h
//  SwiftInAction-006-005
//
//  Created by zhihua on 14-7-9.
//  Copyright (c) 2014年 ucai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MathUtil : NSObject

@property (strong, nonatomic) id prop;

//定义了addUtil方法
- (int)addUtil:(int)a b:(int)b;

@end