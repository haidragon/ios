//
//  MathUtil.m
//  SwiftInAction-006-005
//
//  Created by zhihua on 14-7-9.
//  Copyright (c) 2014年 ucai. All rights reserved.
//

#import "MathUtil.h"

//导入Xcode自动生成的头文件，需要在编译选项里设置导出模块和名称
#import "SwiftInAction-Swift.h"


@implementation MathUtil : NSObject

- (int)addUtil:(int)a b:(int)b {
    //创建swift的对象
    SwiftObj *ob = [SwiftObj new];
    //调用swift对象的方法
    int base = [ob getBase:@"fromOC"];
    //输出信息
    NSLog(@"Object-C addUtil call getBase: %i", base);
    
    //返回求和总数
    return a + b + base;
}

@end