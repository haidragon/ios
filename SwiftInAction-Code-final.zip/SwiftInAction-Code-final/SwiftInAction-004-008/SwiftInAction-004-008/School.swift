//
//  School.swift
//  SwiftInAction004008
//
//  Created by wuxing on 14/9/7.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

public class School
{
    var students:[Student]
    init()
    {
        students = [Student(name: "xiaoming", age: 20, gender:"Male")]
    }
    
}