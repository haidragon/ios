//
//  SwiftInAction-004-008.h
//  SwiftInAction-004-008
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SwiftInAction004008-Swift.h"
//! Project version number for SwiftInAction-004-008.
FOUNDATION_EXPORT double SwiftInAction_004_008VersionNumber;

//! Project version string for SwiftInAction-004-008.
FOUNDATION_EXPORT const unsigned char SwiftInAction_004_008VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftInAction_004_008/PublicHeader.h>


