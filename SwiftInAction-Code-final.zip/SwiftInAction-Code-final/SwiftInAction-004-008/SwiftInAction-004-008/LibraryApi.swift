//
//  LibraryApi.swift
//  SwiftInAction-004-008
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

@objc public class Student{
    var name:String = ""
    var age:Int = 0
    var gender:String = ""
    @objc public init(name:String, age:Int, gender:String)
    {
        self.name  = name
        self.age = age
        self.gender = gender
        
    }
     @objc private func getName() -> String
    {
        return name
    }
    
     @objc internal func getAge() -> Int
    {
        return age
    }
    
     @objc public func getGender()->String
    {
        return gender
    }
}
