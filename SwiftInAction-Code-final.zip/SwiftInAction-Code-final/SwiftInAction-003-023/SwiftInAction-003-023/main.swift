//
//  main.swift
//  SwiftInAction-003-023
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

enum Animation2048Type
{
    case None   //无动画
    case New    //新出现动画
    case Merge  //合并动画
    func description()->String
    {
        switch(self)
        {
        case .None:
            return "无动画"
        case .New:
            return "新出现动画"
        case  .Merge:
            return "合并动画"
        }
    }
}

println(Animation2048Type.Merge.description())