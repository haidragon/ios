//
//  Section4.swift
//  SwiftInAction-005-003
//
//  Created by krisley on 14-9-13.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section4: NSObject{
    func totalTest(){
        part1()
    }
    
    func part1(){
        let num1 : NSNumber = 1
        let num2 = NSNumber(integer:2)
        let num3 = NSNumber(integer: 3)
        
        NSNumber(unsignedInteger: 1)
        NSNumber(integer:1)
        NSNumber(float:1.1)
        NSNumber(double:3.2)
        NSNumber(bool:true)
        
        NSNumber(integer:1)
        NSNumber(unsignedInteger:1)
        NSNumber(float:1.1)
        NSNumber(double:3.2)
        NSNumber(bool:true)
        let boolV : NSNumber = true
        let bool = boolV.boolValue
        let intV : NSNumber = 1
        let int = intV.integerValue
        let floatV : NSNumber = 1.1
        let float = floatV.floatValue
        let doubleV : NSNumber = 3.2
        let double = doubleV.doubleValue
        let uintV : NSNumber = 1
        let uint = uintV.unsignedIntegerValue
        
        var f:Float
        var number:NSNumber=NSNumber(integer: 100)
        f=Float(number)
        println("f=\(f);number=\(number)")
        number=12.3
        println("number=\(number)")
        var b:Bool = true
        number = b
        println("b=\(b);number=\(number)")
        b = Bool(NSNumber(integer: 100))
        println("b=\(b)")
    }
    
}