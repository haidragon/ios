//
//  MainViewController.swift
//  Swift2048-002
//
//  Created by wuxing on 14/9/13.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import UIKit
class MainViewController:UIViewController
    {
    //游戏方格维度
    var dimension:Int = 4
    //游戏过关最大值
    var maxnumber:Int = 2048 {
        didSet{
            gmodel.maxnumber = maxnumber
        }
    }
    
    //数字格子的宽度
    var width:CGFloat = 50
    //格子与格子的间距
    var padding:CGFloat = 6
    
    //保存背景图数据
    var backgrounds:Array<UIView>!
    
    var gmodel:GameModel!
    //var gmodel:GameModelBA
    //var gmodel:GameModelMatrix
    var score:ScoreView!
    
    var bestscore:ScoreView!
    
    //保存界面上的数字Label数据
    var tiles: Dictionary<NSIndexPath, TileView>!
    //保存实际数字值的一个字典
    var tileVals: Dictionary<NSIndexPath, Int>!
    
    
    init()
    {
        self.backgrounds = Array<UIView>()
        super.init(nibName:nil, bundle:nil)
        self.tiles = Dictionary()
        self.tileVals = Dictionary()
    
    }
    required init(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
    }
    func setupButtons()
    {
        var btnreset = ViewFactory.createButton("重置", action: Selector("resetTapped"), sender:self)
        btnreset.frame.origin.x = 50
        btnreset.frame.origin.y = 450
        self.view.addSubview(btnreset)
        
        var btngen = ViewFactory.createButton("新数",
            action:Selector("genTapped"),sender:self)
        btngen.frame.origin.x = 170
        btngen.frame.origin.y = 450
        self.view.addSubview(btngen)
        
    }
    func resetTapped()
    {
        println("reset")
        resetUI()
        gmodel.initTiles()
        for i in 0..<2
        {
            genNumber()
        }
    }
    func genTapped()
    {
        genNumber()
    }
    //根据数据模型重新
    func initUI()
    {
        for i in 0..<dimension
        {
            for j in 0..<dimension
            {
                var index = i*self.dimension + j
                if(gmodel.tiles[index] != 0)
                {
                    insertTile((i,j),value:gmodel.tiles[index])
                }
            }
        }
    }

    func resetUI()
    {
        for(key, tile) in tiles
        {
            tile.removeFromSuperview()
        }
        tiles.removeAll(keepCapacity: true)
        tileVals.removeAll(keepCapacity: true)
    }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        //改成主视图背景白色背景
        self.view.backgroundColor = UIColor.whiteColor()
        setupGameMap()
        setupScoreLabels()
        setupSwipeGuestures()
        setupButtons()
        self.gmodel = GameModel(dimension: self.dimension,
            maxnumber:self.maxnumber, score:score, bestscore:bestscore)
        for i in 0..<2
        {
            genNumber()
        }
    }
    
    func setupScoreLabels()
    {
        score = ScoreView(stype: ScoreType.Common)
        score.frame.origin = CGPointMake(50, 80)
        score.changeScore(value: 0)
        self.view.addSubview(score)
        
        
        bestscore = ScoreView(stype: ScoreType.Best)
        bestscore.frame.origin.x = 170
        bestscore.frame.origin.y = 80
        bestscore.changeScore(value: 0)
        self.view.addSubview(bestscore)
        
    }
    func setupGameMap()
    {
        var x:CGFloat = 50
        var y:CGFloat = 150
        
        for i in 0..<dimension
        {
            println(i)
            y = 150
            for j in 0..<dimension
            {
                //初始化视图
                var background = UIView(frame:CGRectMake(x, y, width, width))
                background.backgroundColor = UIColor.darkGrayColor()
                
                self.view.addSubview(background)
                //将视图保存起来，以备后用
                backgrounds.append(background)
                y += padding + width
            }
            x += padding+width
        }
    }
    
    func setupSwipeGuestures()
    {
        //监控向上的方向，相应的处理方法 swipeUp
        let upSwipe = UISwipeGestureRecognizer(target:self, action:Selector("swipeUp"))
        
        upSwipe.numberOfTouchesRequired = 1
        upSwipe.direction = UISwipeGestureRecognizerDirection.Up
        self.view.addGestureRecognizer(upSwipe)
        //监控向下的方向，相应的处理方法 swipeDown
        let downSwipe = UISwipeGestureRecognizer(target: self, action: Selector("swipeDown"))
        downSwipe.numberOfTouchesRequired = 1
        downSwipe.direction = UISwipeGestureRecognizerDirection.Down
        self.view.addGestureRecognizer(downSwipe)
        //监控向左的方向，相应的处理方法 swipeLeft
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: Selector("swipeLeft"))
        leftSwipe.numberOfTouchesRequired = 1
        leftSwipe.direction = UISwipeGestureRecognizerDirection.Left
        self.view.addGestureRecognizer(leftSwipe)
        //监控向右的方向，相应的处理方法 swipeRight
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: Selector("swipeRight"))
        rightSwipe.numberOfTouchesRequired = 1
        rightSwipe.direction = UISwipeGestureRecognizerDirection.Right
        self.view.addGestureRecognizer(rightSwipe)
        
    }
    func _showTip(direction:String)
    {
        let alertController = UIAlertController(title: "提示", message: "你刚刚向\(direction)滑动了！", preferredStyle: UIAlertControllerStyle.Alert)
        alertController.addAction(UIAlertAction(title: "确定", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alertController, animated: true, completion: nil)
    }
    func swipeUp()
    {
        println("swipeUp")
        _showTip("上")
        
    }
    func swipeDown()
    {
        println("swipeDown")
        _showTip("下")
    }
    func swipeLeft()
    {
        println("swipeLeft")
        _showTip("左")
    }
    func swipeRight()
    {
        println("swipeRight")
        _showTip("右")
    }

    
    func insertTile(pos:(Int, Int), value:Int)
    {
        let (row, col) = pos;
        
        let x = 50 + CGFloat(col) * (width + padding)
        let y = 150 + CGFloat(row) * (width + padding)
        
        let tile = TileView(pos: CGPointMake(x,y), width:width, value:value)
        self.view.addSubview(tile)
        self.view.bringSubviewToFront(tile)
        var index = NSIndexPath(forRow: row, inSection: col)
        tiles[index] = tile
        tileVals[index] = value
        //先将数字块大小置为原始尺寸的 1/10
        tile.layer.setAffineTransform(CGAffineTransformMakeScale(0.1,0.1))
        
        //设置动画效果，动画时间长度 1 秒。
        UIView.animateWithDuration(1, delay:0.01, options:UIViewAnimationOptions.TransitionNone, animations:
            {
                ()-> Void in
                //在动画中，数字块有一个角度的旋转。 
                tile.layer.setAffineTransform(CGAffineTransformMakeRotation(90))
            },
            completion:{
                (finished:Bool) -> Void in
                UIView.animateWithDuration(1, animations:{
                    ()-> Void in
                    //完成动画时，数字块复原
                    tile.layer.setAffineTransform(CGAffineTransformIdentity)
                })
                
        })

    }

    func genNumber()
    {
        //用于确定随机数的概率
        let randv = Int(arc4random_uniform(10))
        println(randv)
        var seed:Int = 2
        //因为有 10%的机会，出现1，所以这里是 10%的机会给 4
        if(randv == 1)
        {
            seed = 4
        }
        //随机生成行号和列号
        let col =  Int(arc4random_uniform(UInt32(dimension)))
        let row = Int(arc4random_uniform(UInt32(dimension)))
        if(gmodel.isFull())
        {
            println("位置已经满了")
            return
        }
        if(gmodel.setPosition(row, col:col, value:seed)==false)
        {
            genNumber()
            return
        }
        //执行后续操作
        insertTile((row, col), value: seed)
    }
}
