//
//  ViewController.swift
//  SwiftInAction-006-003
//
//  Created by zhihua on 14-7-9.
//  Copyright (c) 2014年 ucai. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var label:UILabel = UILabel(frame:CGRectMake(100, 100,300,100));
        label.text = "输出结果在控制台"
        self.view.addSubview(label)
        //测试Swift调用Object的XML库功能
        testXML()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func testXML() {
        //获取xml文件路径
        var path = NSBundle.mainBundle().pathForResource("users", ofType:"xml")
        //获取xml文件内容
        var xmlData = NSData(contentsOfFile:path!)
        //可以转换为字符串输出查看
        //println(NSString(data:xmlData, encoding:NSUTF8StringEncoding))
        
        //使用NSData对象初始化文档对象
        //这里的语法已经把OC的初始化函数直接转换过来了
        var doc:GDataXMLDocument = GDataXMLDocument(data:xmlData, options : 0, error : nil)
        
        //获取Users节点下的所有User节点，显式转换为element类型编译器就不会警告了
        //var users = doc.rootElement().elementsForName("User") as GDataXMLElement[]
        
        //通过XPath方式获取Users节点下的所有User节点，在路径复杂时特别方便
        var users = doc.nodesForXPath("//User", error:nil) as! [GDataXMLElement]
        
        for user in users {
            //User节点的id属性
            let uid = user.attributeForName("id").stringValue()
            //获取name节点元素
            let nameElement = user.elementsForName("name")[0] as! GDataXMLElement
            //获取元素的值
            let uname =  nameElement.stringValue()
            //获取tel子节点
            let telElement = user.elementsForName("tel")[0] as! GDataXMLElement
            //获取tel节点下mobile和home节点
            let mobile = (telElement.elementsForName("mobile")[0] as! GDataXMLElement).stringValue()
            let home = (telElement.elementsForName("home")[0] as! GDataXMLElement).stringValue()
            //输出调试信息
            println("User: uid:\(uid),uname:\(uname),mobile:\(mobile),home:\(home)")
        }


        
        /*
         通过另一个OC库DDXML解析，方法基本相同
        */
        
        /*
        //构造XML文档
        var doc = DDXMLDocument(data: xmlData, options:0, error:nil)
        
        //利用XPath来定位节点（XPath是XML语言中的定位语法，类似于数据库中的SQL功能）
        var users = doc.nodesForXPath("//User", error:nil) as DDXMLElement[]
        for user in users {
            let uid = user.attributeForName("id").stringValue()
            //DDXMLElementAdditions提供了elementForName获取单个节点，不用获取数组了
            let uname = user.elementForName("name").stringValue()
            //获取tel节点的子节点
            let telElement = user.elementForName("tel") as DDXMLElement
            let mobile = (telElement.elementForName("mobile") as DDXMLElement).stringValue()
            let home = (telElement.elementForName("home") as DDXMLElement).stringValue()
            println("User: uid:\(uid),uname:\(uname),mobile:\(mobile),home:\(home)")
        }
        */
        
    }

}

