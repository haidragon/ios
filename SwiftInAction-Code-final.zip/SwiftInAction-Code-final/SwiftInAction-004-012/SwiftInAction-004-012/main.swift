//
//  main.swift
//  SwiftInAction-004-012
//
//  Created by wuxing on 14/7/30.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

extension Int
    {
    var mm:String{
        return "\(self/1) mm"
    }
    var cm:String
    {
        return "\(self/10) cm"
    }
    
    var dm:String{
        return "\(self/100) dm"
    }
    
    var m:String
    {
        return "\(self/1000) m"
    }
    var km:String
    {
        return "\(self/(1000*1000)) km"
    }
}

var value = 2000000000
println(value.mm)
println(value.cm)
println(value.dm)
println(value.m)
println(value.km)