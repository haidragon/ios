//
//  main.swift
//  SwiftInAction-004-019
//
//  Created by wuxing on 14/7/31.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
struct Student:Hashable{
    var no:Int?
    var name:String?
    var hashValue: Int {
        return self.no!
    }
}
func == (lhs: Student, rhs: Student) -> Bool
{
    return lhs.no == rhs.no
}

struct School{
    var name:String?
    var addr:String
}

var students:Dictionary<Student,School> = Dictionary(minimumCapacity: 2)
println(students)
