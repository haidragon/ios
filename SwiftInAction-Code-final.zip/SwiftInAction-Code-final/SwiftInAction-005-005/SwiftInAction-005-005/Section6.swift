//
//  Section6.swift
//  SwiftInAction-005-005
//
//  Created by krisley on 14-9-15.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section6: NSObject{
    func totalTest(){
        part1()
    }
    
    // MARK: - 以下内容对应5.6.1节代码
    func part1(){
        let swiftDictionary :Dictionary<String, String> = ["key1":"value1","key2":"value2"]
        let nsDictionary : NSDictionary = swiftDictionary
        println(nsDictionary.allValues)
        
        let swiftNSDic = nsDictionary as Dictionary
        for(key,value:AnyObject) in swiftNSDic {
            println("\(key): \(value)")
        }
        
        var nsmutabDictionary = NSMutableDictionary(dictionary:swiftDictionary)
        nsmutabDictionary.removeObjectForKey("key1")
        println(nsmutabDictionary)
    }
    
    // MARK: - 以下内容对应5.6.2节代码
    func part2()
    {
        let nsDictionary1 = NSDictionary(object: "value1", forKey: "key1")
        
        let nsDictionary2 = NSDictionary(objects: ["value1","value2"], forKeys: ["key1","key2"])
        
        let swiftDictionary=["key1":"value1","key2":"value2"]
        let nsDictionary = NSDictionary(dictionary: swiftDictionary)
    }
    
    // MARK: - 以下内容对应5.6.3节代码
    func part3()
    {
        let swiftDictionary=["key1":"value1","key2":"value2"]
        let nsDictionary = NSDictionary(dictionary: swiftDictionary)
        println(swiftDictionary.count)
        println(nsDictionary.count)
        
        let sortKeys = nsDictionary.keysSortedByValueUsingComparator({
            ($0 as! String).compare($1 as! String)
            })
        println("sortKeys: \(sortKeys)")
        
        println(nsDictionary.objectForKey("key1"))
        println(nsDictionary["key1"])
        
        println(nsDictionary.objectsForKeys(["key1","key2","key3"], notFoundMarker: "Not Found"))
    }
}