//
//  main.swift
//  SwiftInAction-003-025
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
struct Position
{
    var longtitue:Double = 0
    var latitue:Double = 0
}
struct Leave
{
    var color:String!
}
//生物类
class Living
{
    func grow(){}
}
//动物类
class Animal:Living
{
    func move(){} //行动方法
}
//植物类
class Plant:Living
{
    var leaves:Array<Leave>!     //叶子属性
    var position:Position!   //生长位置属性
    func photosynthesis(){} //光合作用方法
}
//水果类
class Fruit:Plant
{
    func fruct(){}  //结果方法
}
//桃子类
class Peach:Fruit
{
    func graft(){}  //嫁接方法
}

