//
//  GlobalVars.swift
//  SwiftInAction-002-100
//
//  Created by wuxing on 14/7/7.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

var str = "Hello, World!"

func getSum(n:Int)->Int
{
    var sum = 0
    println("使用了 getSum 函数:\(var_in_main)")
    for i in 1...n
    {
        sum += i
    }
    return sum
} 
let sum = getSum(100)


