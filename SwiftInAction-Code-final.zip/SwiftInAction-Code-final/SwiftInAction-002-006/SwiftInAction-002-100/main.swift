//
//  main.swift
//  SwiftInAction-002-100
//
//  Created by wuxing on 14/7/7.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println(str)
//这里会编译错误，提示Invalid redeclaration of 'str'
//var str="in main.swift"
func output()
{
    var str = "In Output"
    println(str)
}

output()

for i in [1,2,3,4,5]
{
    println(i)
    var sum = 0
    sum += i
    
}

var var_in_main = "Var In Main"
//调用 sum 错误，因为 sum 只能在 for 循环内使用
//println(sum)
//调用 i 错误，因为 i 只能在 for 循环内使用
//println(i)


//println("sum = \(sum)")


