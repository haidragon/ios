//
//  main.swift
//  SwiftInAction-002-002
//
//  Created by aba on 14-8-3.
//  Copyright (c) 2014年 aba. All rights reserved.
//

import Foundation

var ExceptionLogs=[
    "Warning: Login In System with no password Check By DB",
    "Warning: View customer list without DB",
    "Error: You have no Jurisdiction",
    "Warning: A Operate is no effect",
    "Error: Illicit close program"]

var warningCount = 0
var errorCount = 0
//现在我们可以用hasPrefix 方法来统计日志中警告和错误提醒的数量
for atitle in ExceptionLogs{          //使用for in 遍历字符串日志数组
    if atitle.hasPrefix("Warning") {   //判断字符串头是否包含Warning
    ++warningCount                    //如果包含则count+1
    }
    if atitle.hasPrefix("Error") {     //判断字符串头是否包含Error
    ++errorCount
    //关于前置和后置加加运算我们会在后面详细介绍
    }
}
println("warning have \(warningCount) and error have \(errorCount).")
//输出warning have 3 and error have 2.

var DBCount = 0
//然后使用hasSuffix 方法来统计哪些操作和数据库进行了交互
for atitle in ExceptionLogs{
    //使用for in 遍历字符串日志数组
    if atitle.hasSuffix ("Check By DB") {
    //判断字符串尾是否包含Check By DB
    ++DBCount //如果包含则count+1
    }
}
println("Have \(DBCount) Count Check By DB")
//输出：Have 1 Count Check By DB
