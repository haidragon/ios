//
//  exchange.h
//  SwiftInAction006002
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

//交换函数的原型
void exchange(int *a, int *b);
