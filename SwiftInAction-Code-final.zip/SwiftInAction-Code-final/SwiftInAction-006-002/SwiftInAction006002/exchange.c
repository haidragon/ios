//
//  exchange.c
//  SwiftInAction006002
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#include <stdio.h>
//交换函数的实现，实现两个整数的交换
void exchange(int *a, int *b)
{
    int tmp = *a;
    *a = *b;
    *b = tmp;
}