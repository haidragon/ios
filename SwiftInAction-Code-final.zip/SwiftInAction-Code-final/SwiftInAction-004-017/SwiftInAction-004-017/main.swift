//
//  main.swift
//  SwiftInAction-004-017
//
//  Created by wuxing on 14/7/31.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
class Student {
    var country: Country?
}

class Country {
    var name:String="China"
}

var xiaoli = Student()
//xiaoli.country = Country()
//fatal error: unexpectedly found nil while unwrapping an Optional value
//println(xiaoli.country!.name)

if let country = xiaoli.country?.name {
    println("Xiaoli is from \(country).")
} else {
    println("未取得国籍")
}
