//
//  GameModel.swift
//  Swift2048-006
//
//  Created by wuxing on 14/9/13.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
class GameModel
{
    var dimension:Int = 0
    
    var tiles:Array<Int>!
    var mtiles:Array<Int>!
    var scoredelegate:ScoreViewProtocol!
    var bestscoredelegage:ScoreViewProtocol!
    
    var score:Int = 0
    var bestscore:Int  = 0{
        didSet{
            bestscoredelegage.changeScore(value: bestscore)
        }
    }    
    var maxnumber:Int = 0
    
    init(dimension:Int, maxnumber:Int, score:ScoreViewProtocol, bestscore:ScoreViewProtocol)
    {
        self.maxnumber = maxnumber
        self.dimension = dimension
        self.scoredelegate = score
        self.bestscoredelegage = bestscore
        self.dimension = dimension
        self.maxnumber = maxnumber
    
        self.initTiles()
    
    }
    
    func initTiles()
    {
        self.tiles = Array<Int>(count:self.dimension*self.dimension, repeatedValue:0)
        self.mtiles = Array<Int>(count:self.dimension*self.dimension, repeatedValue:0)
    }
    //找出空位置
    func emptyPositions()-> [Int]
    {
    
            var emptytiles = Array<Int>()
            //var index:Int
            for i in 0..<(dimension*dimension)
            {
                if(tiles[i] == 0)
                {
                    emptytiles.append(i)
                }
            }
            return emptytiles
    }
            //位置是否已满
    func isFull()-> Bool
    {
        if(emptyPositions().count == 0)
        {
            return true
        }
        return false
    }
    //输出当前数据模型
    func printTiles()
    {
        println(tiles)
        println("输出数据模型数据")
        var count = tiles.count
        for var i=0; i<count; i++
        {
            if (i+1) % Int(dimension) == 0
            {
                println(tiles[i])
            }
            else
            {
                print("\(tiles[i])\t")
            }
        }
        println("")
        
    }
    func reflowUp()
    {
        copyToMtiles()
        var index:Int
        //从最后一行开始往上找
        //为什么是 i>0 ，而不是 i>= 0，因为第一行不用再动了
        for var i=dimension-1; i>0; i--
        {
            for j in 0..<dimension
            {
                index = self.dimension * i+j
                //如果当前位置有值，上一行没有值
                if(mtiles[index-self.dimension] == 0
                    && (mtiles[index] > 0))
                {
                    //把下一行的值赋值到上一行
                    mtiles[index-self.dimension] = mtiles[index]
                    mtiles[index] = 0
                    
                    var subindex:Int = index
                    //因为当前行发生了移动，得让其后面的行跟上
                    //否则滑动重排之后，会出现空隙
                    while(subindex+self.dimension<mtiles.count)
                    {
                        if(mtiles[subindex+self.dimension]>0)
                        {
                            mtiles[subindex] = mtiles[subindex+self.dimension]
                            mtiles[subindex+self.dimension] = 0
                        }
                        subindex += self.dimension
                    }
                }
            }
        }
         copyFromMtiles()
    }
    func reflowDown()
    {
        copyToMtiles()
        var index:Int
        //从第一行开始往下找
        //只找到dimension-1行，因为最下面一行不用再动了
        for i in 0..<dimension-1 {
            for j in 0..<dimension {
                index = self.dimension * i + j
                //如果当前位置有值，下一行相应的位置没有值
                if (mtiles[index+self.dimension] == 0)
                    && (mtiles[index] > 0)
                {
                    //把这一行的值赋值到下一行
                    mtiles[index+self.dimension] = mtiles[index]
                    mtiles[index] = 0
                    var subindex:Int = index
                    //对后面的内容进行检查
                    //因为当下面的行发生了移动，得让上面的行跟上
                    //否则滑动重排之后，会出现空隙
                    while((subindex-self.dimension)>=0)
                    {
                        if (mtiles[subindex-self.dimension]>0)
                        {
                            mtiles[subindex] = mtiles[subindex-self.dimension]
                            mtiles[subindex-self.dimension] = 0
                        }
                        subindex -= self.dimension
                    }
                    
                }
            }
        }
         copyFromMtiles()
    }
    func reflowLeft()
    {
        copyToMtiles()
        var index:Int
        //从最右列开始往左找
        //只找到第2列，因为第1列的数据不用再动了
        for i in 0..<dimension {
            for var j=dimension-1; j>0; j-- {
                index = self.dimension * i + j
                //如果当前位置有值，而且其左边一列，即前一个位置没有值，则移动
                if (mtiles[index-1] == 0)
                    && (mtiles[index] > 0)
                {
                    mtiles[index-1] = mtiles[index]
                    mtiles[index] = 0
                    var subindex:Int = index
                    //对右边的内容进行检查，如果出现空隙则补上
                    while((subindex+1) < i*dimension+dimension)
                    {
                        if (mtiles[subindex+1]>0)
                        {
                            mtiles[subindex] = mtiles[subindex+1]
                            mtiles[subindex+1] = 0
                        }
                        subindex += 1
                    }
                    
                }
            }
        }
         copyFromMtiles()
    }
    func isSuccess() -> Bool
    {
        for i in 0..<(dimension*dimension)
        {
            if(tiles[i] >= maxnumber)
            {
                return true
            }
        }
        return false
    }
    func reflowRight()
    {
        copyToMtiles()
        var index:Int
        //从第1列开始往右找
        //只找到dimension-1列，因为最右面一列不用再动了
        for i in 0..<dimension {
            for j in 0..<dimension-1 {
                index = self.dimension * i + j
                //如果当前位置有值，而且右边位置没有值
                if (mtiles[index+1] == 0)
                    && (mtiles[index] > 0)
                {
                    mtiles[index+1] = mtiles[index]
                    mtiles[index] = 0
                    var subindex:Int = index
                    //对后面的内容进行检查
                    //补上右边的空白块，以免出现空隙
                    while((subindex-1) > i*dimension-1)
                    {
                        if (mtiles[subindex-1]>0)
                        {
                            mtiles[subindex] = mtiles[subindex-1]
                            mtiles[subindex-1] = 0
                        }
                        subindex -= 1
                    }
                    
                }
            }
        }
         copyFromMtiles()
    }

    func copyToMtiles()
    {
        for i in 0..<self.dimension * self.dimension
        {
            mtiles[i] = tiles[i]
        }
    }
    
    func copyFromMtiles()
    {
        for i in 0..<self.dimension * self.dimension
        {
            tiles[i] = mtiles[i]
        }
        
        
    }

    //如果返回 false ,表示该位置 已经有值
    func setPosition(row:Int, col:Int, value:Int) -> Bool
    {
        assert(row >= 0 && row < dimension)
        assert(col >= 0 && col < dimension)
        //3行4列，即  row=2 , col=3  index=2*4+3 = 11
        //4行4列，即  3*4+3 = 15
        var index = self.dimension * row + col
        var val = tiles[index]
        if(val > 0)
        {
            println("该位置(\(row), \(col))已经有值了")
            return false
        }
        tiles[index] = value
        
        return true
    }
    
    
    //向上合并的方法
    func  mergeUp()
    {
        copyToMtiles()
        var index:Int
        //从上到上合
        for var i=dimension-1; i>0; i--
        {
            for j in 0..<dimension
            {
                index = self.dimension * i + j
                //如果相同列上，而且相邻的数字相等
                if((mtiles[index] > 0) && (mtiles[index-self.dimension] == mtiles[index]))
                {
                    //将数字合并到上面行的位置 ，下面的数字清空
                    mtiles[index-self.dimension] = mtiles[index] * 2
                    mtiles[index] = 0
                }
            }
        }
        copyFromMtiles()
    }
    //向下合并的方法
    func mergeDown()
    {
        copyToMtiles()
        var index:Int
        //从上到下合
        for i in 0..<dimension-1 {
            for j in 0..<dimension {
                
                index = self.dimension * i + j
                //如果下一行的数字和当前行数字相等
                if (mtiles[index] > 0 && mtiles[index+self.dimension] == mtiles[index])
                {
                    //将叠加合并后的结果放置到下一行。上一行的数字清空
                    mtiles[index+self.dimension] = mtiles[index] * 2
                    mtiles[index] = 0
                }
            }
        }
        copyFromMtiles()
    }
    //向左合并的方法
    func mergeLeft()
    {
        copyToMtiles()
        var index:Int
        //从右到左合并
        for i in 0..<dimension {
            for var j=dimension-1; j>0; j-- {
                index = self.dimension * i + j
                //如果右边和左边的数字相邻相等，则合并
                if (mtiles[index] > 0 && mtiles[index-1] == mtiles[index])
                {
                    //叠加合并到左边一列，右边一列当前位置上的数字清空
                    mtiles[index-1] = mtiles[index] * 2
                    mtiles[index] = 0
                }
            }
        }
        copyFromMtiles()
    }
    //向右合并的方法
    func mergeRight()
    {
        copyToMtiles()
        var index:Int
        //从左向右合
        for i in 0..<dimension {
            for j in 0..<dimension-1 {
                index = self.dimension * i + j
                //如果当前数字和正右边相邻的数字相等，则可以合并
                if (mtiles[index] > 0 && mtiles[index+1] == mtiles[index])
                {
                    //叠加合并到右边一列，左边当前位置相应的数字清空
                    mtiles[index+1] = mtiles[index] * 2
                    mtiles[index] = 0
                }
            }
        }
        copyFromMtiles()
    }
    

    
}
