//
//  main.swift
//  SwiftInAction-004-010
//
//  Created by wuxing on 14/7/28.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

class Student{
    var name=""
    init(name:String)
    {
        println("init:"+name)
        self.name = name
    }
}

infix operator  >< { associativity right }
func >< (inout left: Student, inout right: Student) -> Student{
    var tmp=left
    left = right
    right = tmp
    return tmp
}

var a = Student(name: "xiaowang")
var b = Student(name: "xiaoli")
println(a.name)
println(b.name)
var ret = a><b
println(a.name)
println(b.name)



