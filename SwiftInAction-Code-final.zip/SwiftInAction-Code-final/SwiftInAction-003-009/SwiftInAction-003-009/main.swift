//
//  main.swift
//  SwiftInAction-003-009
//
//  Created by wuxing on 14/7/27.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Student{
    var name:String = ""
    var classno:Int = 0
    var from:String = ""
    let country:String="中国"
}
//这样输出会出错，因为 country 是常量属性，必须声明了对象才能使用
//println(Student.country)

var student = Student()
//正确
println(student.country)
class Teacher
{
    var classno:Int = 0
    var defined = false
    var from:String = ""
    var name:String = ""
    class var country:String{
        get{
            return "中国"
        }
        set{
            //解开这句这里会导致循环赋值
            //也无法变更值
            //Teacher.country = (newValue)
        }
    }
}
Teacher.country = "美国"
//这样输出不会出错，因为在 Teacher 类中， country 是类属性
println(Teacher.country)

struct People
{
    var classno:Int = 0
    var from:String = ""
    var name:String = ""
    static var country:String = "中国"
}
People.country = "法国"
//这样输出不会出错，因为在 People 结构体中， country 是静态属性
println(People.country)






