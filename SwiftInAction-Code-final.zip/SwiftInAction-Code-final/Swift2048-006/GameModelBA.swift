//
//  GameModelBA.swift
//  Swift2048-006
//
//  Created by wuxing on 14/9/13.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
class GameModelBA
{
    var dimension:Int = 0
    
    
    var tiles:Array<Array<Int>>
    
    //由外部来传入维度值
    init(dimension:Int)
    {
        self.dimension = dimension
        
        self.tiles = Array(count:self.dimension, repeatedValue:Array(count:
        self.dimension, repeatedValue:0))
        
    }
    //找出空位置
    func emptyPositions()-> [Int]
    {
        
        var emptytiles = Array<Int>()
        //var index:Int
        for row in 0..<self.dimension
        {
            for col in 0..<self.dimension
            {
                if(tiles[row][col] == 0)
                {
                    emptytiles.append(tiles[row][col])
                }
            }
        }
        return emptytiles
    }
        //位置是否已满
    func isFull()-> Bool
    {
        if(emptyPositions().count == 0)
        {
            return true
        }
        return false
    }
    //输出当前数据模型
    func printTiles()
    {
        println(tiles)
        println("输出数据模型数据")
        var count = tiles.count
        for row in 0..<self.dimension
        {
            for col in 0..<self.dimension
            {
                print("\(tiles[row][col])\t")
            }
            println("")
        }
            println("")
            
    }
}
