//
//  GameModelMatrix.swift
//  Swift2048-006
//
//  Created by wuxing on 14/9/13.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
//自定义矩阵数据结构
struct Matrix {
    let rows: Int, columns: Int
    var grid: [Int]
    init(rows: Int, columns: Int) {
        self.rows = rows
        self.columns = columns
        grid = Array(count: rows * columns, repeatedValue: 0)
    }
    func indexIsValidForRow(row: Int, column: Int) -> Bool {
        return row >= 0 && row < rows && column >= 0 && column < columns
    }
    subscript(row: Int, column: Int) -> Int {
        get {
            assert(indexIsValidForRow(row, column: column), "超出范围")
            return grid[(row * columns) + column]
        }
        set {
            assert(indexIsValidForRow(row, column: column), "超出范围")
            grid[(row * columns) + column] = newValue
        }
    }
}

class GameModelMatrix
{
    var dimension:Int = 0
    
    var tiles:Matrix
    
    //由外部来传入维度值
    init(dimension:Int)
    {
        self.dimension = dimension
        
        self.tiles = Matrix(rows: self.dimension, columns: self.dimension)
    }
    //找出空位置
    func emptyPositions()-> [Int]
    {
        
        var emptytiles = Array<Int>()
        //var index:Int
        for row in 0..<self.dimension
        {
            for col in 0..<self.dimension
            {
                var val = tiles[row,col]
                if(val == 0)
                {
                    emptytiles.append(tiles[row, col])
                }
            }
        }
        return emptytiles
    }
    //位置是否已满
    func isFull()-> Bool
    {
        if(emptyPositions().count == 0)
        {
            return true
        }
        return false
    }
    //输出当前数据模型
    func printTiles()
    {
        println(tiles)
        println("输出数据模型数据")
        for row in 0..<self.dimension
        {
            for col in 0..<self.dimension
            {
                print("\(tiles[row, col])\t")
            }
            println("")
        }
        println("")
        
    }
}
