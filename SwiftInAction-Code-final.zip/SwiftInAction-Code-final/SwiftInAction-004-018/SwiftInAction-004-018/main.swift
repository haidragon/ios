//
//  main.swift
//  SwiftInAction-004-018
//
//  Created by wuxing on 14/7/31.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class Student {
    var country: Country?
}

class Country {
    var name:String="China"
    var capital:Capital?
}



class Capital{
    var mayor:String="Mayor Liu"
    var name:String="Beijing"
}

var xiaoli = Student()
xiaoli.country = Country()
//xiaoli.country?.capital = Capital()
//fatal error: unexpectedly found nil while unwrapping an Optional value
//println(xiaoli.country!.name)
if let country = xiaoli.country?.capital?.mayor {
    println("Xiaoli is from \(xiaoli.country?.capital?.name)")
} else {
    println("不知道哪来的！！！")
    
}