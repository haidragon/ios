//
//  Section7.swift
//  SwiftInAction-005-006
//
//  Created by krisley on 14-9-15.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section7: NSObject{
    func totalTest(){
        part1()
    }
    
    func part1(){
        let swiftArray=["a","b","c","a"]
        let nsset=NSSet(array:swiftArray)
        println(nsset)
        
        var nsMutableSet=NSMutableSet(array:swiftArray)
        nsMutableSet.addObject("d")
        println(nsMutableSet)
    }
    
    func part2()
    {
        let swiftArray=["a","b","c"]
        let nsset=NSSet(array:swiftArray)
        println(nsset.count)
        
        let arr=nsset.allObjects
        println(arr[0])
        
        println(nsset.containsObject("b"))
        println(nsset.member("b"))
        
        func isSubset()
        {
            let nsset1=NSSet(array:["a","b","c"])
            let nsset2=NSSet(array:["b","c"])
            println(nsset2.isSubsetOfSet(nsset1 as Set<NSObject>))
        }
        isSubset()
        
        func isIntersect(){
            let nsset1=NSSet(array:["a","b","c"])
            let nsset2=NSSet(array:["b","c","d"])
            println(nsset2.intersectsSet(nsset1 as Set<NSObject>))
        }
        isIntersect()
        
        func isEqual(){
            let nsset1=NSSet(array:["a","b"])
            let nsset2=NSSet(array:["b","a"])
            println(nsset2.isEqualToSet(nsset1 as Set<NSObject>))
            
            if(nsset1==nsset2){
                println("equal");
            }
        }
        isEqual()
        
        func intersectSet(){
            let nsset1=NSSet(array:["a","b","c"])
            let nsset2=NSMutableSet(array:["b","c","d"])
            nsset2.intersectSet(nsset1 as Set<NSObject>)
            println(nsset2)
        }
        intersectSet()
        
        func unionSet(){
            let nsset1=NSSet(array:["a","b","c"])
            let nsset2=NSMutableSet(array:["b","c","d"])
            nsset2.unionSet(nsset1 as Set<NSObject>)
            println(nsset2)
        }
        unionSet()
        
        func minusSet(){
            let nsset1=NSSet(array:["a","b","c"])
            let nsset2=NSMutableSet(array:["b","c","d"])
            nsset2.minusSet(nsset1 as Set<NSObject>)
            println(nsset2)
        }
        minusSet()
    }
    func part3(){
        var arr = ["php","swift","java"] as [AnyObject]
        var nscountedset=NSCountedSet()
        nscountedset.addObjectsFromArray(arr)
        nscountedset.addObject("php")
        nscountedset.removeObject("swift")
        println(nscountedset.countForObject("php"))
        println(nscountedset.countForObject("swift"))
        println(nscountedset.countForObject("java"))
    }
}