//
//  Section2.swift
//  SwiftInAction-005-001
//
//  Created by krisley on 14-9-13.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section2: NSObject{
    func totalTest(){
        part2()
    }
    
    func part2(){
        
        var str = "Hello World"
        (str as String).lowercaseString
        //下面是Objective-C语法下NSString的初始化方法之一
//        NSString *string = [[NSString alloc] initWithFormat:@"%@ %@",@"Hello", @"World"];
        
        var string = NSString(format:"%@ %@","Hello","world")
        string = string.lowercaseString
        
        // 调用stringByReplacingOccurrencesOfString方法替换字符中得world位swfit
        string = string.stringByReplacingOccurrencesOfString("world",withString:"swift")
        println(string)
    }
}