//
//  main.swift
//  SwiftInAction-003-027
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

println("Hello, World!")

//
//  main.swift
//  SwiftInAction-003-026
//
//  Created by wuxing on 14/7/29.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

//桃子类
/*class Peach
{
var leaves:Array<Leave>!     //叶子属性
var position:Position!   //生长位置属性
func photosynthesis(){} //光合作用方法
func grow(){}   //生长方法
func fruct(){}  //结果方法
func graft(){}  //嫁接方法
}*/
struct Position
{
    var longtitude:Double = 0
    var latitude:Double = 0
}
struct Leave
{
    var color:String!
    init(color:String)
    {
        self.color = color
        println("\(color)叶子")
    }
}
//生物类
class Living
{
    /*@final*/ func grow(){
        println("生长中")
    }
}
//植物类
class Plant:Living
{
    var leaves:Array<Leave>!     //叶子属性
    var position:Position   //生长位置属性
    override init()
    {
        self.position = Position(longtitude:0,latitude:0)
    }
    func photosynthesis(){
        println("光合作用中")
    } //光合作用方法
}
//水果类
class Fruit:Plant
{
    func fruct(){
        println("结果中")
    }  //结果方法
}
//桃子类
class Peach:Fruit
{
    override var position:Position{
    get{
        return super.position
    }
    set{
        super.position = newValue
    }
    }
    override init()
    {
        super.init()
        self.leaves = Array(count:10,repeatedValue:Leave(color:"绿"))
        self.position = Position(longtitude: 138, latitude: 28)
    }
    func graft(){
        println("嫁接中")
    }  //嫁接方法
    //重写方法 grow
    override func grow()
    {
        println("桃子以自己的方式生长着")
    }
    //此时不是重写，而是方法重载
    func grow(speed:Int)
    {
        println("增长速度\(speed)")
    }
    func life()
    {
        self.grow()
        println("生长在(\(self.position.longtitude), \(self.position.latitude))处，长出了\(self.leaves.count)片叶子")
        self.photosynthesis()
        self.graft()
        self.fruct()
    }
}

var peach = Peach()
peach.life()



