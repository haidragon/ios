//
//  main.swift
//  SwiftInAction-002-001
//
//  Created by aba on 14-8-3.
//  Copyright (c) 2014年 aba. All rights reserved.
//

import Foundation

var str:String="Hello, World!"

//str=1024

let Constr="i love my country"

//Constr="2048"  //会编译报错，不能修改常量

//var tmpCount:Int32＝2.8 //会编译报错，类型字面量和所标注的类型不同

println(Constr) //输出 Constr

