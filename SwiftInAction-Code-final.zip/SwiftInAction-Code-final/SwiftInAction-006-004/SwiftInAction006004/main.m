//
//  main.m
//  SwiftInAction006004
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "SwiftInAction006004-Swift.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Pig *pig = [[Pig alloc]init];
        Dog *dog = [[Dog alloc]init];
        Tortoise *tortoise = [[Tortoise alloc]init];
        Piegon *piegon = [[Piegon alloc]init];
        
        NSArray *animals = [[NSArray alloc] initWithObjects:pig, dog, tortoise,piegon,nil];
        id obj;
        for(int i = 0; i < [animals count]; i++)
        {
            obj = [animals objectAtIndex:i];
            [obj run];
        }

    }
    return 0;
}
