//
//  Animal.swift
//  SwiftInAction006003
//
//  Created by wuxing on 14/7/20.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

@objc protocol Animal
{
    @objc func run()
}

@objc class Dog:NSObject,Animal
{
    @objc override init()
    {
        println("My List Dog Init!");
    }
    @objc func run()
    {
        println("My List Dog Run!");
    }
}

@objc class Pig:NSObject,Animal
{
    @objc override init()
    {
        println("My List Pig Init!");
    }
    @objc func run()
    {
        println("My List Pig Walk!");
    }
}

@objc class Tortoise:NSObject,Animal
{
    @objc override init()
    {
        println("My List Tortoise Init!");
    }
    @objc func run()
    {
        println("My List Tortoise Creep!");
    }
}

@objc class Piegon:NSObject,Animal
{
     @objc override init()
    {
        println("My List Piegon Init!");
    }
    @objc func run()
    {
        println("My List Piegon Fly!");
    }
    
}