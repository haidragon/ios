//
//  main.swift
//  SwiftInAction-004-013
//
//  Created by wuxing on 14/7/30.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
protocol Bird
{
    func song()
}
class Chiken:Bird{
     func song()
{
    println("母鸡咯咯")
    }
}
class Pegion:Bird
    {
     func song()
{
    println("鸽子咕咕")
    }
}
class Crow:Bird
    {
     func song()
{
    println("乌鸦呱呱")
    }
}
class Duck:Bird
    {
     func song()
{
    println("鸭子嘎嘎")
    }
}
class Sparrow:Bird
    {
     func song()
{
    println("麻雀唧唧")
    }
}
class Swallow:Bird
    {
     func song()
{
    println("燕子啾啾")
    }
}
var birds:Array<Bird> = [Chiken(), Pegion(), Crow(), Duck(), Sparrow(), Swallow()]
for bird in birds
{
    bird.song()
}
