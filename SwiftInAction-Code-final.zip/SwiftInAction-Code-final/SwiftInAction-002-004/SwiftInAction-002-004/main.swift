//
//  main.swift
//  SwiftInAction-002-004
//
//  Created by aba on 14-8-5.
//  Copyright (c) 2014年 aba. All rights reserved.
//

import Foundation


//在一个校务管理系统中，只有管理权限为8(校长)或9(系统管理员)才能进入管理后台：
var netStatusIsOk:Bool=false
var authorityNo:Int=8
if (authorityNo==8)||(authorityNo==9){
    println("Welcome manager")
    
    //application main
} else {
    println("You have no authority")
    
    //out of application
}


