//
//  Section5.swift
//  SwiftInAction-005-004
//
//  Created by krisley on 14-9-14.
//  Copyright (c) 2014年 SwiftInAction. All rights reserved.
//

import Foundation

class Section5: NSObject{
    func totalTest(){
        part1Seg1()
        part1Seg2()
        part1Seg3()
        part2()
        part3()
    }
    
    //MARK: - 以下为5.5.1节代码
    func part1Seg1(){
        let array:[Int]=[1,2,3,4]
        let nsArray:NSArray=array;
        let swiftArray = nsArray as! [Int]
    }
    
    func part1Seg2(){
        let array:[AnyObject] = [4,2,1,5,3,"happy"]
        let nsArray:NSArray = array
        let swiftArray = nsArray as [AnyObject]
        println(swiftArray)
//        let integerArray = nsArray as [Int] // 出现运行时错误
//        println(integerArray)
    }
    
    func part1Seg3(){
        var swiftArray : [Int] = [1,2,3,4]
        var mutableArray = NSMutableArray(array: swiftArray)
        mutableArray.removeLastObject() //removeLastObject()为NSMutableArray的方法
        println(mutableArray)
    }

    //MARK: - 以下为5.5.2节代码
    func part2(){
        let swiftArray=[1,2,3,4]
        let nsArray1 : NSArray = swiftArray
        let nsArray2 = NSArray(array: swiftArray)
        let nsArray3 = swiftArray as NSArray
        
        let manager = NSFileManager.defaultManager()
        let urlForDocument = manager.URLsForDirectory( NSSearchPathDirectory.DocumentDirectory, inDomains:NSSearchPathDomainMask.UserDomainMask)
        let url = urlForDocument[0] as! NSURL
        var error:NSErrorPointer = nil
        let file = url.URLByAppendingPathComponent("array.txt")
//        println("file: \(file)") //文件路径
        nsArray1.writeToURL(file, atomically: true)
        let nsArray4 = NSArray(contentsOfFile: file.path!)
        let nsArray5 = NSArray(contentsOfURL: file)
        println(nsArray5)
    }
    
    //MARK: - 以下为5.5.3小节代码
    func part3(){
        let swiftArray=[1,2,3,4]
        let nsArray=NSArray(array:swiftArray)
        println("swiftArray count:\(swiftArray.count)")
        println("nsArray count:\(nsArray.count)")
        
        swiftArray.first
        swiftArray[0]
        
        swiftArray.last
        swiftArray[swiftArray.count-1]
        
        let range = NSRange(location:1,length:2)
        let indexSet = NSIndexSet(indexesInRange:range)
        println(nsArray.objectsAtIndexes(indexSet))
        println(swiftArray[1...2])
        
        println("contains 4: \(nsArray.containsObject(4))")
        println("contains 5: \(nsArray.containsObject(5))")
        println(contains(swiftArray,4)) //返回结果为true
        println(nsArray.indexOfObject(4))
        println(find(swiftArray,4))
    }
    
    
    
    
}