//
//  Calculator.swift
//  SwiftInAction-003-007
//
//  Created by wuxing on 14/7/23.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation
class Calcuator
{
    var a:Int = 1;
    var b:Int = 1;
    
    init (a:Int, b:Int)
    {
        self.a = a
        self.b = b
    }
    func sum()->Int
    {
        return a+b
    }
    
    func quotient()-> Int
    {
        return a/b
    }
    
    func product()->Int
    {
        return a*b
    }
    
    func difference()->Int
    {
        return a-b
    }
}
