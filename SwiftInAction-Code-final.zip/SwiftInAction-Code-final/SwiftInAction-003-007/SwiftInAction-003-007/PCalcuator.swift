//
//  PCalcuator.swift
//  SwiftInAction-003-007
//
//  Created by wuxing on 14/7/23.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation

class PCalcuator
{
    var a:Int = 1;
    var b:Int = 1;
    //简写方法
    var sum:Int{
        return a+b
    }
    
    var difference:Int{
        return a-b
    }
    
    var product:Int{
        return a*b
    }
    
    var quotient:Int{
        return a/b
    }
    
    init (a:Int, b:Int)
    {
        self.a = a
        self.b = b
    }
}
