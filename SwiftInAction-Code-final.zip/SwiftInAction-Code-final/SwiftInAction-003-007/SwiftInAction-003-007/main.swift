//
//  main.swift
//  SwiftInAction-003-007
//
//  Created by wuxing on 14/7/23.
//  Copyright (c) 2014年 优才网（www.ucai.cn）. All rights reserved.
//

import Foundation


var cal = Calcuator(a:20,b:10)
println(cal.sum())
println(cal.quotient())
println(cal.product())
println(cal.difference())

var pcal = PCalcuator(a:30,b:10)
println(pcal.sum)
println(pcal.quotient)
println(pcal.product)
println(pcal.difference)

